package com.sprintap.sap.api.controller;

import com.sprintap.sap.domain.entity.transaction.Payment;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for payment operations.
 */
@RestController
@RequestMapping("/api/v1/payment")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Payment", description = "Endpoints for payment operations")
public class PaymentController {

    private final ProducerTemplate producerTemplate;

    @PostMapping
    @Operation(summary = "Post payment to SAP")
    public ResponseEntity<Payment> postPayment(@RequestBody Payment payment) {
        log.info("Posting payment for company: {}", payment.getCompanyCode());

        Payment result = producerTemplate.requestBody("direct:post-payment", payment, Payment.class);

        if (result.getDocumentNumber() != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(result);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }

    @PostMapping("/advance")
    @Operation(summary = "Post advance payment (F47) to SAP")
    public ResponseEntity<Map<String, Object>> postAdvancePayment(@RequestBody Payment payment) {
        log.info("Posting advance payment for company: {}", payment.getCompanyCode());

        @SuppressWarnings("unchecked")
        Map<String, Object> result = producerTemplate.requestBody(
            "direct:post-advance-payment", payment, Map.class);

        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }

    @GetMapping("/{companyCode}/{documentNumber}")
    @Operation(summary = "Get payment details from SAP")
    public ResponseEntity<Payment> getPaymentDetails(
            @PathVariable String companyCode,
            @PathVariable String documentNumber,
            @RequestParam(required = false, defaultValue = "") String fiscalYear) {

        log.info("Getting payment details: {}/{}", companyCode, documentNumber);

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("documentNumber", documentNumber);
        headers.put("fiscalYear", fiscalYear);

        Payment result = producerTemplate.requestBodyAndHeaders(
            "direct:get-payment-details", null, headers, Payment.class);

        if (result != null && result.getDocumentNumber() != null) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
