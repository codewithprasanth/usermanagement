package com.sprintap.sap.api.controller;

import com.sprintap.sap.domain.entity.transaction.Invoice;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for invoice operations.
 */
@RestController
@RequestMapping("/api/v1/invoice")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Invoice", description = "Endpoints for invoice operations")
public class InvoiceController {

    private final ProducerTemplate producerTemplate;

    @PostMapping
    @Operation(summary = "Create invoice in SAP")
    public ResponseEntity<Invoice> createInvoice(@RequestBody Invoice invoice) {
        log.info("Creating invoice for vendor: {}", invoice.getVendorId());

        Invoice result = producerTemplate.requestBody("direct:create-invoice", invoice, Invoice.class);

        if (result.getInvoiceDocNumber() != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(result);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }

    @PostMapping("/simulate")
    @Operation(summary = "Simulate invoice posting in SAP")
    @SuppressWarnings("unchecked")
    public ResponseEntity<Map<String, Object>> simulateInvoice(@RequestBody Invoice invoice) {
        log.info("Simulating invoice for vendor: {}", invoice.getVendorId());

        Map<String, Object> result = producerTemplate.requestBody(
            "direct:simulate-invoice", invoice, Map.class);

        return ResponseEntity.ok(result);
    }

    @PostMapping("/check")
    @Operation(summary = "Check for duplicate invoice in SAP")
    @SuppressWarnings("unchecked")
    public ResponseEntity<Map<String, Object>> checkDuplicateInvoice(
            @RequestParam String companyCode,
            @RequestParam String vendorId,
            @RequestParam String reference,
            @RequestParam BigDecimal amount,
            @RequestParam String currency,
            @RequestParam String documentDate) {

        log.info("Checking duplicate invoice: vendor={}, ref={}", vendorId, reference);

        Invoice invoice = new Invoice();
        invoice.setCompanyCode(companyCode);
        invoice.setVendorId(vendorId);
        invoice.setReferenceDocNumber(reference);
        invoice.setGrossAmount(amount);
        invoice.setCurrencyCode(currency);
        invoice.setDocumentDate(LocalDate.parse(documentDate));

        Map<String, Object> result = producerTemplate.requestBody(
            "direct:check-invoice", invoice, Map.class);

        return ResponseEntity.ok(result);
    }

    @PostMapping("/{invoiceId}/reverse")
    @Operation(summary = "Reverse an invoice in SAP")
    public ResponseEntity<Map<String, Object>> reverseInvoice(
            @PathVariable String invoiceId,
            @RequestParam String reason,
            @RequestParam String reversalDate) {

        log.info("Reversing invoice: {}", invoiceId);

        Map<String, Object> headers = new HashMap<>();
        headers.put("invoiceId", invoiceId);
        headers.put("reason", reason);
        headers.put("reversalDate", reversalDate);

        @SuppressWarnings("unchecked")
        Map<String, Object> result = producerTemplate.requestBodyAndHeaders(
            "direct:reverse-document", null, headers, Map.class);

        return ResponseEntity.ok(result);
    }
}
