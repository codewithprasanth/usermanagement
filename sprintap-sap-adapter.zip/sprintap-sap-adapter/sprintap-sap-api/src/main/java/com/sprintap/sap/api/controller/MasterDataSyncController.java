package com.sprintap.sap.api.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * REST controller for master data synchronization from SAP.
 */
@RestController
@RequestMapping("/api/v1/sync")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Master Data Sync", description = "Endpoints for synchronizing master data from SAP")
public class MasterDataSyncController {

    private final ProducerTemplate producerTemplate;

    @PostMapping("/vendors")
    @Operation(summary = "Sync vendors from SAP")
    public ResponseEntity<Map<String, Object>> syncVendors(
            @RequestParam String companyCode,
            @RequestParam(required = false) String vendorId,
            @RequestParam(required = false) String vendorIdTo,
            @RequestParam(required = false) String vendorAccountGroup) {

        log.info("Triggering vendor sync for company: {}", companyCode);

        String syncId = UUID.randomUUID().toString();

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("syncId", syncId);
        if (vendorId != null) headers.put("vendorId", vendorId);
        if (vendorIdTo != null) headers.put("vendorIdTo", vendorIdTo);
        if (vendorAccountGroup != null) headers.put("vendorAccountGroup", vendorAccountGroup);

        // Fire-and-forget async call using virtual threads
        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-vendor", null, headers)
        );

        Map<String, Object> response = new HashMap<>();
        response.put("syncId", syncId);
        response.put("status", "INITIATED");
        response.put("message", "Vendor sync initiated for company " + companyCode);

        return ResponseEntity.accepted().body(response);
    }

    @PostMapping("/vendors/sync-single")
    @Operation(summary = "Sync single vendor from SAP")
    public ResponseEntity<Map<String, Object>> syncSingleVendor(
            @RequestParam String companyCode,
            @RequestParam String vendorId) {

        log.info("Syncing single vendor: {} for company: {}", vendorId, companyCode);

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("vendorId", vendorId);

        @SuppressWarnings("unchecked")
        Map<String, Object> result = producerTemplate.requestBodyAndHeaders(
            "direct:sync-single-vendor", null, headers, Map.class);

        return ResponseEntity.ok(result);
    }

    @PostMapping("/cost-centers")
    @Operation(summary = "Sync cost centers from SAP")
    public ResponseEntity<Map<String, Object>> syncCostCenters(
            @RequestParam String companyCode,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate) {

        log.info("Triggering cost center sync for company: {}", companyCode);

        String syncId = UUID.randomUUID().toString();

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("syncId", syncId);
        if (fromDate != null) headers.put("fromDate", fromDate);
        if (toDate != null) headers.put("toDate", toDate);

        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-cost-centers", null, headers)
        );

        Map<String, Object> response = new HashMap<>();
        response.put("syncId", syncId);
        response.put("status", "INITIATED");
        response.put("message", "Cost center sync initiated for company " + companyCode);

        return ResponseEntity.accepted().body(response);
    }

    @PostMapping("/gl-accounts")
    @Operation(summary = "Sync GL accounts from SAP")
    public ResponseEntity<Map<String, Object>> syncGlAccounts(
            @RequestParam String companyCode,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate) {

        log.info("Triggering GL account sync for company: {}", companyCode);

        String syncId = UUID.randomUUID().toString();

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("syncId", syncId);
        if (fromDate != null) headers.put("fromDate", fromDate);
        if (toDate != null) headers.put("toDate", toDate);

        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-gl-accounts", null, headers)
        );

        Map<String, Object> response = new HashMap<>();
        response.put("syncId", syncId);
        response.put("status", "INITIATED");
        response.put("message", "GL account sync initiated for company " + companyCode);

        return ResponseEntity.accepted().body(response);
    }

    @PostMapping("/wht-codes")
    @Operation(summary = "Sync withholding tax codes from SAP")
    public ResponseEntity<Map<String, Object>> syncWhtCodes(
            @RequestParam String companyCode,
            @RequestParam String countryCode) {

        log.info("Triggering WHT code sync for company: {}, country: {}", companyCode, countryCode);

        String syncId = UUID.randomUUID().toString();

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("countryCode", countryCode);
        headers.put("syncId", syncId);

        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-wht-codes", null, headers)
        );

        Map<String, Object> response = new HashMap<>();
        response.put("syncId", syncId);
        response.put("status", "INITIATED");
        response.put("message", "WHT code sync initiated");

        return ResponseEntity.accepted().body(response);
    }

    @PostMapping("/payment-terms")
    @Operation(summary = "Sync payment terms from SAP")
    public ResponseEntity<Map<String, Object>> syncPaymentTerms(
            @RequestParam String companyCode) {

        log.info("Triggering payment terms sync for company: {}", companyCode);

        String syncId = UUID.randomUUID().toString();

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("syncId", syncId);

        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-payment-terms", null, headers)
        );

        Map<String, Object> response = new HashMap<>();
        response.put("syncId", syncId);
        response.put("status", "INITIATED");
        response.put("message", "Payment terms sync initiated");

        return ResponseEntity.accepted().body(response);
    }

    @PostMapping("/all")
    @Operation(summary = "Sync all master data from SAP")
    public ResponseEntity<Map<String, Object>> syncAllMasterData(
            @RequestParam String companyCode) {

        log.info("Triggering full master data sync for company: {}", companyCode);

        String syncId = UUID.randomUUID().toString();

        Map<String, Object> headers = new HashMap<>();
        headers.put("companyCode", companyCode);
        headers.put("syncId", syncId);

        // Trigger all sync routes asynchronously
        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-vendor", null, new HashMap<>(headers))
        );
        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-cost-centers", null, new HashMap<>(headers))
        );
        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-gl-accounts", null, new HashMap<>(headers))
        );
        Thread.ofVirtual().start(() ->
            producerTemplate.sendBodyAndHeaders("direct:sync-payment-terms", null, new HashMap<>(headers))
        );

        Map<String, Object> response = new HashMap<>();
        response.put("syncId", syncId);
        response.put("status", "INITIATED");
        response.put("message", "Full master data sync initiated for company " + companyCode);

        return ResponseEntity.accepted().body(response);
    }
}
