package com.sprintap.sap.api.controller;

import com.sprintap.sap.domain.entity.transaction.PurchaseOrder;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for purchase order operations.
 */
@RestController
@RequestMapping("/api/v1/purchase-order")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Purchase Order", description = "Endpoints for purchase order operations")
public class PurchaseOrderController {

    private final ProducerTemplate producerTemplate;

    @GetMapping("/{poNumber}")
    @Operation(summary = "Get purchase order details from SAP")
    public ResponseEntity<PurchaseOrder> getPurchaseOrderDetails(
            @PathVariable String poNumber,
            @RequestParam(defaultValue = "true") boolean includeAccountAssignment) {

        log.info("Getting PO details: {}", poNumber);

        Map<String, Object> headers = new HashMap<>();
        headers.put("poNumber", poNumber);
        headers.put("includeAccountAssignment", includeAccountAssignment);

        PurchaseOrder result = producerTemplate.requestBodyAndHeaders(
            "direct:get-po-details", null, headers, PurchaseOrder.class);

        if (result != null && result.getPoNumber() != null) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{poNumber}/sync")
    @Operation(summary = "Sync purchase order from SAP")
    public ResponseEntity<PurchaseOrder> syncPurchaseOrder(@PathVariable String poNumber) {
        log.info("Syncing PO: {}", poNumber);

        Map<String, Object> headers = new HashMap<>();
        headers.put("poNumber", poNumber);
        headers.put("includeAccountAssignment", true);

        PurchaseOrder result = producerTemplate.requestBodyAndHeaders(
            "direct:sync-po", null, headers, PurchaseOrder.class);

        return ResponseEntity.ok(result);
    }

    @GetMapping("/{poNumber}/pricing")
    @Operation(summary = "Get purchase order pricing from SAP")
    @SuppressWarnings("unchecked")
    public ResponseEntity<Map<String, Object>> getPoPricing(@PathVariable String poNumber) {
        log.info("Getting PO pricing: {}", poNumber);

        Map<String, Object> headers = new HashMap<>();
        headers.put("poNumber", poNumber);

        Map<String, Object> result = producerTemplate.requestBodyAndHeaders(
            "direct:get-po-pricing", null, headers, Map.class);

        return ResponseEntity.ok(result);
    }
}
