package com.sprintap.sap.api.advice;

import com.sprintap.sap.domain.exception.SapAuthenticationException;
import com.sprintap.sap.domain.exception.SapBusinessException;
import com.sprintap.sap.domain.exception.SapCommunicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler for REST API.
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(SapBusinessException.class)
    public ResponseEntity<Map<String, Object>> handleSapBusinessException(SapBusinessException ex) {
        log.error("SAP business error: {}", ex.getMessage());

        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", OffsetDateTime.now());
        error.put("status", HttpStatus.BAD_REQUEST.value());
        error.put("error", "SAP Business Error");
        error.put("message", ex.getMessage());
        error.put("errorCode", ex.getErrorCode());
        error.put("sapMessages", ex.getMessages());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }

    @ExceptionHandler(SapCommunicationException.class)
    public ResponseEntity<Map<String, Object>> handleSapCommunicationException(SapCommunicationException ex) {
        log.error("SAP communication error: {}", ex.getMessage(), ex);

        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", OffsetDateTime.now());
        error.put("status", HttpStatus.SERVICE_UNAVAILABLE.value());
        error.put("error", "SAP Communication Error");
        error.put("message", ex.getMessage());
        error.put("errorCode", ex.getErrorCode());
        error.put("retryable", ex.isRetryable());

        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(error);
    }

    @ExceptionHandler(SapAuthenticationException.class)
    public ResponseEntity<Map<String, Object>> handleSapAuthenticationException(SapAuthenticationException ex) {
        log.error("SAP authentication error: {}", ex.getMessage());

        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", OffsetDateTime.now());
        error.put("status", HttpStatus.UNAUTHORIZED.value());
        error.put("error", "SAP Authentication Error");
        error.put("message", ex.getMessage());
        error.put("errorCode", ex.getErrorCode());

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalArgumentException(IllegalArgumentException ex) {
        log.warn("Invalid argument: {}", ex.getMessage());

        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", OffsetDateTime.now());
        error.put("status", HttpStatus.BAD_REQUEST.value());
        error.put("error", "Invalid Request");
        error.put("message", ex.getMessage());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) {
        log.error("Unexpected error: {}", ex.getMessage(), ex);

        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", OffsetDateTime.now());
        error.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        error.put("error", "Internal Server Error");
        error.put("message", "An unexpected error occurred");

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }
}
