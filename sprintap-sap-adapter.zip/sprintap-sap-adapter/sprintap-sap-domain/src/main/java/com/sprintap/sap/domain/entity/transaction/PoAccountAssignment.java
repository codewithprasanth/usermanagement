package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * PO Account Assignment domain entity.
 * Maps to scm_txn_po_account_assignment table and BAPI_PO_GETDETAIL1 POACCOUNT.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PoAccountAssignment {

    private UUID id;
    private String poNumber;
    private String poItem;

    // SAP: POACCOUNT fields
    private String serialNo;           // SAP: SERIAL_NO
    private String glAccountCode;      // SAP: GL_ACCOUNT
    private String costCenterCode;     // SAP: COSTCENTER
    private String profitCenterCode;   // SAP: PROFIT_CTR
    private String businessAreaCode;   // SAP: BUS_AREA
    private String controllingArea;    // SAP: CO_AREA
    private String wbsElement;         // SAP: WBS_ELEMENT
    private String internalOrder;      // SAP: ORDERID
    private String assetNumber;        // SAP: ASSET_NO
    private BigDecimal quantity;       // SAP: QUANTITY
    private BigDecimal distributionPercent; // SAP: DISTR_PERC
    private BigDecimal netValue;       // SAP: NET_VALUE

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;
}
