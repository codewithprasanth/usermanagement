package com.sprintap.sap.domain.entity.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Vendor bank account domain entity.
 * Maps to scm_mas_vendor_bank table and ZSGBFIFM_VENDORBANK_ECM BAPI.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VendorBank {

    private UUID id;

    // SAP: LIFNR
    private String vendorId;

    // SAP: BANKS
    private String bankCountry;

    // SAP: BANKL
    private String bankKey;

    // SAP: ACC_NO
    private String bankAccountNumber;

    // SAP: IBAN
    private String iban;

    // SAP: SWIFT
    private String swiftCode;

    // SAP: ACC_NAME
    private String accountHolderName;

    // SAP: BANK_NAME
    private String bankName;

    // SAP: BVTYP
    private String partnerBankType;

    // SAP: BKREF
    private String bankReference;

    // Flags
    private boolean isActive;

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;
}
