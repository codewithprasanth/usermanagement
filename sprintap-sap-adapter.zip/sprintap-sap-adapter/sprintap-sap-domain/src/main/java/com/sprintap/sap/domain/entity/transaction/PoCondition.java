package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * PO Condition/Pricing domain entity.
 * Maps to scm_txn_po_condition table and BAPI_PO_GETDETAIL1 POCOND.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PoCondition {

    private UUID id;
    private String poNumber;

    // SAP: POCOND fields
    private String poItem;             // SAP: ITM_NUMBER
    private String conditionNumber;    // SAP: CONDITION_NO
    private String conditionCounter;   // SAP: COND_COUNT
    private String conditionType;      // SAP: COND_TYPE
    private BigDecimal conditionValue; // SAP: COND_VALUE
    private String currencyCode;       // SAP: CURRENCY
    private String conditionUnit;      // SAP: COND_UNIT
    private BigDecimal conditionPriceUnit; // SAP: COND_P_UNT
    private boolean isStatistical;     // SAP: STAT_CON

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;
}
