package com.sprintap.sap.domain.entity.master;

import com.sprintap.sap.domain.entity.SyncStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Vendor master data domain entity.
 * Maps to scm_mas_vendor table and ZGTMMFM_OT_VENDOR_DETAILS BAPI.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Vendor {

    private UUID id;

    // SAP: LIFNR
    private String vendorId;

    // SAP: NAME1
    private String vendorName;

    // SAP: NAME2
    private String vendorName2;

    // SAP: LAND1
    private String countryCode;

    // SAP: ORT01
    private String city;

    // SAP: STRAS
    private String street;

    // SAP: PSTLZ
    private String postalCode;

    // SAP: REGIO
    private String region;

    // SAP: TELF1
    private String telephone;

    // SAP: TELFX
    private String fax;

    // SAP: EMAIL
    private String email;

    // SAP: STCEG
    private String vatRegistrationNumber;

    // SAP: TAX_NUMBER
    private String taxNumber;

    // SAP: KTOKK
    private String vendorAccountGroup;

    // SAP: INDUSTRY
    private String industryCode;

    // Flags
    private boolean isActive;
    private boolean isBlocked;

    // Sync metadata
    private SyncStatus syncStatus;
    private OffsetDateTime lastSyncAt;
    private String lastSyncError;

    // Extended attributes for non-essential SAP fields
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Check if vendor is valid for transactions.
     */
    public boolean isValidForTransaction() {
        return isActive && !isBlocked && vendorId != null;
    }

    /**
     * Mark as synced successfully.
     */
    public void markSynced() {
        this.syncStatus = SyncStatus.COMPLETED;
        this.lastSyncAt = OffsetDateTime.now();
        this.lastSyncError = null;
    }

    /**
     * Mark sync as failed.
     */
    public void markSyncFailed(String error) {
        this.syncStatus = SyncStatus.FAILED;
        this.lastSyncAt = OffsetDateTime.now();
        this.lastSyncError = error;
    }
}
