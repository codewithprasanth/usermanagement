package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Invoice tax data domain entity.
 * Maps to scm_txn_invoice_tax table and ZGTFIFM_OT_INC_INVOICE_CREATE IT_TAXDATA.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceTax {

    private UUID id;
    private UUID invoiceId;

    // SAP: IT_TAXDATA fields
    private String taxCode;            // SAP: TAX_CODE
    private String taxJurisdictionCode; // SAP: TAXJURCODE
    private BigDecimal taxAmount;       // SAP: TAX_AMOUNT
    private BigDecimal taxBaseAmount;   // SAP: TAX_BASE_AMOUNT
    private String conditionType;       // SAP: COND_TYPE

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;
}
