package com.sprintap.sap.domain.entity.transaction;

import com.sprintap.sap.domain.entity.SyncStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Purchase Order domain entity.
 * Maps to scm_txn_purchase_order table and BAPI_PO_GETDETAIL1 BAPI.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PurchaseOrder {

    private UUID id;

    // SAP: POHEADER fields
    private String poNumber;           // SAP: PURCHASEORDER / PO_NUMBER
    private String companyCode;        // SAP: COMP_CODE
    private String vendorId;           // SAP: VENDOR
    private String documentType;       // SAP: DOC_TYPE
    private LocalDate documentDate;    // SAP: DOC_DATE
    private LocalDate createdOn;       // SAP: CREAT_DATE
    private String createdBySap;       // SAP: CREATED_BY
    private String purchasingOrg;      // SAP: PURCH_ORG
    private String purchasingGroup;    // SAP: PUR_GROUP
    private String currencyCode;       // SAP: CURRENCY
    private BigDecimal exchangeRate;   // SAP: EXCH_RATE
    private String paymentTermsCode;   // SAP: PMNTTRMS
    private String incoterms1;         // SAP: INCOTERMS1
    private String incoterms2;         // SAP: INCOTERMS2

    // Calculated totals
    private BigDecimal netValue;       // Sum of item values
    private BigDecimal grQuantity;     // Goods receipt quantity
    private BigDecimal irQuantity;     // Invoice receipt quantity

    // Line items
    @Builder.Default
    private List<PurchaseOrderItem> items = new ArrayList<>();

    // Account assignments
    @Builder.Default
    private List<PoAccountAssignment> accountAssignments = new ArrayList<>();

    // Conditions/Pricing
    @Builder.Default
    private List<PoCondition> conditions = new ArrayList<>();

    // Status
    private String releaseStatus;
    private boolean isDeleted;
    private SyncStatus syncStatus;
    private OffsetDateTime lastSyncAt;

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Add a PO item.
     */
    public void addItem(PurchaseOrderItem item) {
        if (items == null) {
            items = new ArrayList<>();
        }
        item.setPoNumber(this.poNumber);
        items.add(item);
    }

    /**
     * Calculate total PO value.
     */
    public BigDecimal calculateNetValue() {
        if (items == null || items.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return items.stream()
            .filter(item -> !item.isDeleted())
            .map(item -> item.getNetPrice().multiply(item.getQuantity()))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Get open quantity for invoicing.
     */
    public BigDecimal getOpenQuantity() {
        if (grQuantity == null || irQuantity == null) {
            return BigDecimal.ZERO;
        }
        return grQuantity.subtract(irQuantity);
    }

    /**
     * Check if PO is valid for invoice reference.
     */
    public boolean isValidForInvoice() {
        return !isDeleted && poNumber != null;
    }
}
