package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

/**
 * Clearing document reference.
 * Maps to ZGTFIFM_F48_POST TT_CLEARDOCS.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClearingDocument {

    private UUID id;
    private UUID paymentId;

    // SAP: TT_CLEARDOCS fields
    private String documentNumber;     // SAP: BELNR
    private String companyCode;        // SAP: BUKRS
    private String fiscalYear;         // SAP: GJAHR
    private String lineItem;           // SAP: BUZEI
    private String clearingDocument;   // SAP: AUGBL
    private LocalDate clearingDate;    // SAP: AUGDT
}
