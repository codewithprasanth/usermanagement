package com.sprintap.sap.domain.entity.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Payment Terms master data entity.
 * Maps to scm_mas_payment_terms table.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentTerms {

    private UUID id;
    private String paymentTermsCode;
    private String description;
    private String companyCode;
    private Integer netDays;
    private Integer discount1Days;
    private BigDecimal discount1Percent;
    private Integer discount2Days;
    private BigDecimal discount2Percent;
    private String baselineDate;
    private String paymentTermsCategory;
    private boolean active;
    private Map<String, Object> extendedAttributes;
    private String createdBy;
    private OffsetDateTime createdAt;
    private String modifiedBy;
    private OffsetDateTime modifiedAt;
}
