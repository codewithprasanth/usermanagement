package com.sprintap.sap.domain.exception;

import lombok.Getter;

/**
 * Base exception for SAP adapter errors.
 */
@Getter
public class SapAdapterException extends RuntimeException {

    private final String errorCode;
    private final boolean retryable;

    public SapAdapterException(String message) {
        this(message, "SAP_ERROR", false);
    }

    public SapAdapterException(String message, String errorCode, boolean retryable) {
        super(message);
        this.errorCode = errorCode;
        this.retryable = retryable;
    }

    public SapAdapterException(String message, String errorCode, boolean retryable, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.retryable = retryable;
    }
}
