package com.sprintap.sap.domain.entity.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Cost center master data domain entity.
 * Maps to scm_mas_cost_center table and ZGTFIFM_COST_CENTER_DETAILS BAPI.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CostCenter {

    private UUID id;

    // SAP: KOSTL
    private String costCenterCode;

    // SAP: BUKRS
    private String companyCode;

    // SAP: KOKRS
    private String controllingArea;

    // SAP: PRCTR
    private String profitCenterCode;

    // SAP: KTEXT/LTEXT
    private String description;

    // SAP: VERAK
    private String responsiblePerson;

    // SAP: GSBER
    private String businessAreaCode;

    // SAP: WAERS
    private String currencyCode;

    // Validity dates
    private LocalDate validFrom;
    private LocalDate validTo;

    // Flags
    private boolean isActive;

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Check if cost center is valid on a given date.
     */
    public boolean isValidOn(LocalDate date) {
        boolean afterStart = validFrom == null || !date.isBefore(validFrom);
        boolean beforeEnd = validTo == null || !date.isAfter(validTo);
        return isActive && afterStart && beforeEnd;
    }
}
