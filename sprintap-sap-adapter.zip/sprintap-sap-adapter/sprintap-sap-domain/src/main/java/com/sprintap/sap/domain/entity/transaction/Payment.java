package com.sprintap.sap.domain.entity.transaction;

import com.sprintap.sap.domain.entity.DocumentStatus;
import com.sprintap.sap.domain.entity.SyncStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Payment document domain entity.
 * Maps to scm_txn_payment table and ZGTFIFM_F48_POST BAPI.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Payment {

    private UUID id;

    // SAP Document Info (after posting)
    private String documentNumber;     // SAP: BELNR (returned)
    private String fiscalYear;         // SAP: GJAHR
    private String companyCode;        // SAP: COMP_CODE

    // SAP: IM_HEADER fields
    private String documentType;       // SAP: DOC_TYPE (KZ, etc.)
    private LocalDate documentDate;    // SAP: DOC_DATE
    private LocalDate postingDate;     // SAP: PSTNG_DATE
    private String fiscalPeriod;       // SAP: FIS_PERIOD
    private String referenceDocNumber; // SAP: REF_DOC_NO
    private String headerText;         // SAP: HEADER_TXT
    private String currencyCode;       // SAP: CURRENCY
    private BigDecimal totalAmount;    // Sum of payment items

    // Payment items
    @Builder.Default
    private List<PaymentItem> items = new ArrayList<>();

    // Clearing documents
    @Builder.Default
    private List<ClearingDocument> clearingDocuments = new ArrayList<>();

    // Status
    private DocumentStatus status;
    private SyncStatus syncStatus;
    private String syncError;

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Add a payment item.
     */
    public void addItem(PaymentItem item) {
        if (items == null) {
            items = new ArrayList<>();
        }
        item.setPaymentId(this.id);
        items.add(item);
    }

    /**
     * Mark payment as posted.
     */
    public void markPosted(String sapDocNumber, String sapFiscalYear) {
        this.documentNumber = sapDocNumber;
        this.fiscalYear = sapFiscalYear;
        this.status = DocumentStatus.POSTED;
        this.syncStatus = SyncStatus.COMPLETED;
        this.syncError = null;
    }

    /**
     * Mark posting as failed.
     */
    public void markPostingFailed(String error) {
        this.status = DocumentStatus.DRAFT;
        this.syncStatus = SyncStatus.FAILED;
        this.syncError = error;
    }

    /**
     * Check if payment is valid for posting.
     */
    public boolean isValidForPosting() {
        return companyCode != null
            && documentDate != null
            && postingDate != null
            && currencyCode != null
            && !items.isEmpty();
    }
}
