package com.sprintap.sap.domain.entity;

/**
 * SAP synchronization status.
 */
public enum SyncStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
    PARTIAL
}
