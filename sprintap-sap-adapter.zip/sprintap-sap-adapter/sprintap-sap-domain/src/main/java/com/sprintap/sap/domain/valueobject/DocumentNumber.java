package com.sprintap.sap.domain.valueobject;

import java.util.Objects;

/**
 * Value object representing SAP Document Number (BELNR).
 */
public record DocumentNumber(String value, String fiscalYear) {

    public DocumentNumber {
        Objects.requireNonNull(value, "Document number cannot be null");
        if (value.isBlank() || value.length() > 10) {
            throw new IllegalArgumentException("Document number must be 1-10 characters");
        }
        if (fiscalYear != null && fiscalYear.length() != 4) {
            throw new IllegalArgumentException("Fiscal year must be 4 characters");
        }
    }

    public static DocumentNumber of(String value) {
        return new DocumentNumber(value, null);
    }

    public static DocumentNumber of(String value, String fiscalYear) {
        return new DocumentNumber(value, fiscalYear);
    }

    /**
     * Format document number with leading zeros (SAP format).
     */
    public String toSapFormat() {
        return String.format("%010d", Long.parseLong(value));
    }

    @Override
    public String toString() {
        return fiscalYear != null ? value + "/" + fiscalYear : value;
    }
}
