package com.sprintap.sap.domain.entity.transaction;

import com.sprintap.sap.domain.entity.DocumentStatus;
import com.sprintap.sap.domain.entity.SyncStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Invoice domain entity.
 * Maps to scm_txn_invoice table and ZGTFIFM_OT_INC_INVOICE_CREATE BAPI.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Invoice {

    private UUID id;

    // SAP Document Info (after posting)
    private String invoiceDocNumber;   // SAP: INV_DOC_NO (returned)
    private String fiscalYear;         // SAP: GJAHR

    // Header data - SAP: IS_HEADERDATA
    private String companyCode;        // SAP: COMP_CODE
    private String vendorId;           // From vendor selection
    private boolean invoiceIndicator;  // SAP: INVOICE_IND (X = Invoice)
    private String documentType;       // SAP: DOC_TYPE (RE, KR, etc.)
    private LocalDate documentDate;    // SAP: DOC_DATE
    private LocalDate postingDate;     // SAP: PSTNG_DATE
    private String referenceDocNumber; // SAP: REF_DOC_NO
    private String currencyCode;       // SAP: CURRENCY
    private BigDecimal exchangeRate;   // SAP: EXCH_RATE
    private BigDecimal grossAmount;    // SAP: GROSS_AMOUNT
    private String paymentTermsCode;   // SAP: PMNTTRMS
    private LocalDate baselineDate;    // SAP: BLINE_DATE
    private LocalDate dueDate;         // Calculated
    private String businessAreaCode;   // SAP: BUS_AREA
    private String headerText;         // SAP: HEADER_TXT
    private String itemText;           // SAP: ITEM_TEXT
    private String paymentMethod;      // SAP: PYMT_METH
    private String paymentBlock;       // SAP: PMNT_BLOCK
    private String debitCreditIndicator; // SAP: DE_CRE_IND (H = Credit memo)
    private String personExternal;     // SAP: PERSON_EXT

    // Calculated amounts
    private BigDecimal netAmount;
    private BigDecimal taxAmount;
    private BigDecimal whtAmount;

    // Line items
    @Builder.Default
    private List<InvoiceItem> items = new ArrayList<>();

    // Tax data
    @Builder.Default
    private List<InvoiceTax> taxes = new ArrayList<>();

    // Withholding tax data
    @Builder.Default
    private List<InvoiceWht> withholdingTaxes = new ArrayList<>();

    // Status
    private DocumentStatus status;
    private SyncStatus syncStatus;
    private String syncError;

    // Extended attributes for non-essential SAP fields
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Add an invoice item.
     */
    public void addItem(InvoiceItem item) {
        if (items == null) {
            items = new ArrayList<>();
        }
        item.setInvoiceId(this.id);
        items.add(item);
    }

    /**
     * Calculate total amount from items.
     */
    public BigDecimal calculateTotalFromItems() {
        if (items == null || items.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return items.stream()
            .map(InvoiceItem::getItemAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Check if invoice is valid for posting.
     */
    public boolean isValidForPosting() {
        return companyCode != null
            && vendorId != null
            && documentDate != null
            && postingDate != null
            && grossAmount != null
            && grossAmount.compareTo(BigDecimal.ZERO) != 0
            && !items.isEmpty();
    }

    /**
     * Mark invoice as posted.
     */
    public void markPosted(String sapDocNumber, String sapFiscalYear) {
        this.invoiceDocNumber = sapDocNumber;
        this.fiscalYear = sapFiscalYear;
        this.status = DocumentStatus.POSTED;
        this.syncStatus = SyncStatus.COMPLETED;
        this.syncError = null;
    }

    /**
     * Mark posting as failed.
     */
    public void markPostingFailed(String error) {
        this.status = DocumentStatus.DRAFT;
        this.syncStatus = SyncStatus.FAILED;
        this.syncError = error;
    }

    /**
     * Check if this is a credit memo.
     */
    public boolean isCreditMemo() {
        return "H".equals(debitCreditIndicator) || !invoiceIndicator;
    }
}
