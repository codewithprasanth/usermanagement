package com.sprintap.sap.domain.entity.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Vendor company-specific data domain entity.
 * Maps to scm_mas_vendor_company table.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VendorCompany {

    private UUID id;

    // SAP: LIFNR
    private String vendorId;

    // SAP: BUKRS
    private String companyCode;

    // SAP: AKONT
    private String reconciliationAccount;

    // SAP: ZTERM
    private String paymentTermsCode;

    // SAP: ZWELS
    private String paymentMethod;

    // SAP: HBKID
    private String houseBankId;

    // SAP: LNRZA
    private String alternativePayee;

    // Flags
    private boolean isBlocked;
    private String paymentBlock;

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;
}
