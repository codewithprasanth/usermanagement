package com.sprintap.sap.domain.valueobject;

import java.util.Objects;

/**
 * Value object representing SAP Company Code (BUKRS).
 */
public record CompanyCode(String value) {

    public CompanyCode {
        Objects.requireNonNull(value, "Company code cannot be null");
        if (value.isBlank() || value.length() > 4) {
            throw new IllegalArgumentException("Company code must be 1-4 characters");
        }
    }

    public static CompanyCode of(String value) {
        return new CompanyCode(value);
    }

    @Override
    public String toString() {
        return value;
    }
}
