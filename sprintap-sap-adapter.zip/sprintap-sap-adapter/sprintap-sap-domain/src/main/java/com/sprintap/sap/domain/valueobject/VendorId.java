package com.sprintap.sap.domain.valueobject;

import java.util.Objects;

/**
 * Value object representing SAP Vendor ID (LIFNR).
 */
public record VendorId(String value) {

    public VendorId {
        Objects.requireNonNull(value, "Vendor ID cannot be null");
        if (value.isBlank() || value.length() > 10) {
            throw new IllegalArgumentException("Vendor ID must be 1-10 characters");
        }
    }

    public static VendorId of(String value) {
        return new VendorId(value);
    }

    /**
     * Format vendor ID with leading zeros (SAP format).
     */
    public String toSapFormat() {
        return String.format("%010d", Long.parseLong(value));
    }

    @Override
    public String toString() {
        return value;
    }
}
