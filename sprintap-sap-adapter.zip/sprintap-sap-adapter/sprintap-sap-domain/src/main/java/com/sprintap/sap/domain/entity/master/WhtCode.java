package com.sprintap.sap.domain.entity.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Withholding Tax Code master data entity.
 * Maps to scm_mas_wht_code table.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhtCode {

    private UUID id;
    private String whtCode;
    private String whtType;
    private String description;
    private String countryCode;
    private String companyCode;
    private BigDecimal whtRate;
    private BigDecimal baseAmount;
    private String accumType;
    private LocalDate validFrom;
    private LocalDate validTo;
    private boolean active;
    private Map<String, Object> extendedAttributes;
    private String createdBy;
    private OffsetDateTime createdAt;
    private String modifiedBy;
    private OffsetDateTime modifiedAt;
}
