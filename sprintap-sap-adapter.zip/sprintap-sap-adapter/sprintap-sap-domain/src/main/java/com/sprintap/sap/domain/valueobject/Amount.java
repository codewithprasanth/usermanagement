package com.sprintap.sap.domain.valueobject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * Value object representing a monetary amount with currency.
 */
public record Amount(BigDecimal value, String currency) {

    public Amount {
        Objects.requireNonNull(value, "Amount value cannot be null");
        Objects.requireNonNull(currency, "Currency cannot be null");
        if (currency.isBlank() || currency.length() > 5) {
            throw new IllegalArgumentException("Currency code must be 1-5 characters");
        }
        // Normalize scale to 2 decimal places
        value = value.setScale(2, RoundingMode.HALF_UP);
    }

    public static Amount of(BigDecimal value, String currency) {
        return new Amount(value, currency);
    }

    public static Amount of(String value, String currency) {
        return new Amount(new BigDecimal(value), currency);
    }

    public static Amount zero(String currency) {
        return new Amount(BigDecimal.ZERO, currency);
    }

    public Amount add(Amount other) {
        validateSameCurrency(other);
        return new Amount(this.value.add(other.value), this.currency);
    }

    public Amount subtract(Amount other) {
        validateSameCurrency(other);
        return new Amount(this.value.subtract(other.value), this.currency);
    }

    public Amount multiply(BigDecimal multiplier) {
        return new Amount(this.value.multiply(multiplier), this.currency);
    }

    public Amount negate() {
        return new Amount(this.value.negate(), this.currency);
    }

    public boolean isZero() {
        return value.compareTo(BigDecimal.ZERO) == 0;
    }

    public boolean isPositive() {
        return value.compareTo(BigDecimal.ZERO) > 0;
    }

    public boolean isNegative() {
        return value.compareTo(BigDecimal.ZERO) < 0;
    }

    private void validateSameCurrency(Amount other) {
        if (!this.currency.equals(other.currency)) {
            throw new IllegalArgumentException(
                "Cannot operate on amounts with different currencies: " + this.currency + " vs " + other.currency);
        }
    }

    /**
     * Format amount for SAP (no thousands separator, dot decimal separator).
     */
    public String toSapFormat() {
        return value.toPlainString();
    }

    @Override
    public String toString() {
        return value.toPlainString() + " " + currency;
    }
}
