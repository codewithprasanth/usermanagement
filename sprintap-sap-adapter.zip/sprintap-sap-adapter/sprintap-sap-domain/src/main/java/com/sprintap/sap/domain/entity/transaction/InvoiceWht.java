package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Invoice withholding tax data domain entity.
 * Maps to scm_txn_invoice_wht table and ZGTFIFM_OT_INC_INVOICE_CREATE IT_WITHTAXDATA.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceWht {

    private UUID id;
    private UUID invoiceId;

    // SAP: IT_WITHTAXDATA fields
    private String splitKey;           // SAP: SPLIT_KEY
    private String whtType;            // SAP: WI_TAX_TYPE
    private String whtCode;            // SAP: WI_TAX_CODE
    private BigDecimal whtBaseAmount;  // SAP: WI_TAX_BASE
    private BigDecimal whtAmount;      // SAP: WI_TAX_AMT
    private BigDecimal whtWithheldAmount; // SAP: WI_TAX_WITHHELD_AMT

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;
}
