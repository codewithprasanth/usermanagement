package com.sprintap.sap.domain.entity;

/**
 * Document lifecycle status.
 */
public enum DocumentStatus {
    DRAFT,
    PENDING,
    APPROVED,
    POSTED,
    REVERSED,
    CANCELLED
}
