package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Payment item domain entity.
 * Maps to scm_txn_payment_item table and ZGTFIFM_F48_POST TT_VENDOR_ITEM/TT_BANK_ITEM.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentItem {

    private UUID id;
    private UUID paymentId;

    // Item type: VENDOR or BANK
    private String itemType;

    // SAP: TT_VENDOR_ITEM fields (for vendor items)
    private String vendorId;           // SAP: VENDOR_NO
    private String businessAreaCode;   // SAP: BUS_AREA
    private String paymentMethod;      // SAP: PYMT_METH
    private String itemText;           // SAP: ITEM_TEXT
    private String whtCode;            // SAP: W_TAX_CODE
    private String taxCode;            // SAP: TAX_CODE
    private String profitCenterCode;   // SAP: PROFIT_CTR
    private String poNumber;           // SAP: PO_NUMBER
    private String poItem;             // SAP: PO_ITEM
    private String specialGlIndicator; // SAP: SP_GL_IND
    private BigDecimal amount;         // SAP: AMT_DOCCUR
    private String allocationNumber;   // SAP: ALLOC_NMBR

    // SAP: TT_BANK_ITEM fields (for bank items)
    private String glAccountCode;      // SAP: GL_ACCOUNT
    private LocalDate valueDate;       // SAP: VALUE_DATE

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Check if this is a vendor item.
     */
    public boolean isVendorItem() {
        return "VENDOR".equals(itemType);
    }

    /**
     * Check if this is a bank item.
     */
    public boolean isBankItem() {
        return "BANK".equals(itemType);
    }
}
