package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Purchase Order item domain entity.
 * Maps to scm_txn_po_item table and BAPI_PO_GETDETAIL1 POITEM.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PurchaseOrderItem {

    private UUID id;
    private String poNumber;

    // SAP: POITEM fields
    private String poItem;             // SAP: PO_ITEM
    private String materialNumber;     // SAP: MATERIAL
    private String shortText;          // SAP: SHORT_TEXT
    private String plantCode;          // SAP: PLANT
    private String storageLocation;    // SAP: STGE_LOC
    private String materialGroup;      // SAP: MATL_GROUP
    private BigDecimal quantity;       // SAP: QUANTITY
    private String uomCode;            // SAP: PO_UNIT
    private BigDecimal netPrice;       // SAP: NET_PRICE
    private BigDecimal priceUnit;      // SAP: PRICE_UNIT
    private String taxCode;            // SAP: TAX_CODE
    private String itemCategory;       // SAP: ITEM_CAT
    private String accountAssignmentCategory; // SAP: ACCTASSCAT

    // GR/IR indicators
    private boolean grIndicator;       // SAP: GR_IND
    private boolean irIndicator;       // SAP: IR_IND
    private boolean grBasedIv;         // SAP: GR_BASEDIV
    private boolean noMoreGr;          // SAP: NO_MORE_GR
    private boolean finalInvoice;      // SAP: FINAL_INV

    // Status
    private boolean isDeleted;         // SAP: DELETE_IND

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Calculate item value.
     */
    public BigDecimal calculateValue() {
        if (netPrice == null || quantity == null || priceUnit == null) {
            return BigDecimal.ZERO;
        }
        return netPrice.multiply(quantity).divide(priceUnit, 2, java.math.RoundingMode.HALF_UP);
    }

    /**
     * Check if item requires goods receipt.
     */
    public boolean requiresGoodsReceipt() {
        return grIndicator && !noMoreGr;
    }

    /**
     * Check if item requires invoice receipt.
     */
    public boolean requiresInvoice() {
        return irIndicator && !finalInvoice;
    }
}
