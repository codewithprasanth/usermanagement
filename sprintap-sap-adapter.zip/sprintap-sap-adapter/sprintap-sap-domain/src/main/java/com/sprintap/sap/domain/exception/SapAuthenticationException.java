package com.sprintap.sap.domain.exception;

/**
 * Exception for SAP authentication/authorization failures.
 * These are retryable (token refresh might help).
 */
public class SapAuthenticationException extends SapAdapterException {

    public SapAuthenticationException(String message) {
        super(message, "SAP_AUTH_ERROR", true);
    }

    public SapAuthenticationException(String message, Throwable cause) {
        super(message, "SAP_AUTH_ERROR", true, cause);
    }
}
