package com.sprintap.sap.domain.valueobject;

import lombok.Builder;
import lombok.Data;

/**
 * Value object representing a BAPI return message from SAP.
 */
@Data
@Builder
public class SapReturnMessage {

    /**
     * Message type: S=Success, E=Error, W=Warning, I=Info, A=Abort
     */
    private String type;

    /**
     * Message ID (message class)
     */
    private String id;

    /**
     * Message number
     */
    private String number;

    /**
     * Message text
     */
    private String message;

    /**
     * Log number
     */
    private String logNo;

    /**
     * Message variables
     */
    private String messageV1;
    private String messageV2;
    private String messageV3;
    private String messageV4;

    /**
     * Check if this is an error message.
     */
    public boolean isError() {
        return "E".equals(type) || "A".equals(type);
    }

    /**
     * Check if this is a success message.
     */
    public boolean isSuccess() {
        return "S".equals(type);
    }

    /**
     * Check if this is a warning message.
     */
    public boolean isWarning() {
        return "W".equals(type);
    }

    /**
     * Get full message with variables substituted.
     */
    public String getFullMessage() {
        String result = message;
        if (messageV1 != null) result = result.replace("&1", messageV1);
        if (messageV2 != null) result = result.replace("&2", messageV2);
        if (messageV3 != null) result = result.replace("&3", messageV3);
        if (messageV4 != null) result = result.replace("&4", messageV4);
        return result;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s-%s: %s", type, id, number, getFullMessage());
    }
}
