package com.sprintap.sap.domain.entity.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Invoice line item domain entity.
 * Maps to scm_txn_invoice_item table and ZGTFIFM_OT_INC_INVOICE_CREATE IT_ITEMDATA.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceItem {

    private UUID id;
    private UUID invoiceId;

    // SAP: IT_ITEMDATA fields
    private String invoiceDocItem;     // SAP: INVOICE_DOC_ITEM
    private String poNumber;           // SAP: PO_NUMBER
    private String poItem;             // SAP: PO_ITEM
    private String referenceDocument;  // SAP: REF_DOC (GR or SES number)
    private String referenceDocYear;   // SAP: REF_DOC_YEAR
    private String referenceDocItem;   // SAP: REF_DOC_IT
    private String entrySheetNumber;   // SAP: SHEET_NO
    private String entrySheetItem;     // SAP: SHEET_ITEM
    private String taxCode;            // SAP: TAX_CODE
    private String taxJurisdictionCode; // SAP: TAXJURCODE
    private BigDecimal itemAmount;     // SAP: ITEM_AMOUNT
    private BigDecimal quantity;       // SAP: QUANTITY
    private String uomCode;            // SAP: PO_UNIT
    private String conditionType;      // SAP: COND_TYPE
    private String itemText;           // SAP: ITEM_TEXT
    private boolean finalInvoice;      // SAP: FINAL_INV

    // Extended attributes
    private Map<String, Object> extendedAttributes;

    // Audit
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;

    /**
     * Check if item references a PO.
     */
    public boolean hasPOReference() {
        return poNumber != null && !poNumber.isBlank();
    }

    /**
     * Check if item references a goods receipt.
     */
    public boolean hasGRReference() {
        return referenceDocument != null && !referenceDocument.isBlank();
    }

    /**
     * Check if item references a service entry sheet.
     */
    public boolean hasSESReference() {
        return entrySheetNumber != null && !entrySheetNumber.isBlank();
    }
}
