package com.sprintap.sap.domain.exception;

/**
 * Exception for SAP communication failures (network, timeout, etc.).
 * These are retryable errors.
 */
public class SapCommunicationException extends SapAdapterException {

    public SapCommunicationException(String message) {
        super(message, "SAP_COMM_ERROR", true);
    }

    public SapCommunicationException(String message, Throwable cause) {
        super(message, "SAP_COMM_ERROR", true, cause);
    }
}
