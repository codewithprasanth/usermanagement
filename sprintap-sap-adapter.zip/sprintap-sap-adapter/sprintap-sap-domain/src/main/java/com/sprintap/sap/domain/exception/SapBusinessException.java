package com.sprintap.sap.domain.exception;

import com.sprintap.sap.domain.valueobject.SapReturnMessage;
import lombok.Getter;

import java.util.List;

/**
 * Exception for SAP business errors (validation, duplicate, etc.).
 * These are NOT retryable errors.
 */
@Getter
public class SapBusinessException extends SapAdapterException {

    private final List<SapReturnMessage> messages;

    public SapBusinessException(String message) {
        super(message, "SAP_BUSINESS_ERROR", false);
        this.messages = List.of();
    }

    public SapBusinessException(String message, List<SapReturnMessage> messages) {
        super(message, "SAP_BUSINESS_ERROR", false);
        this.messages = messages != null ? messages : List.of();
    }

    public SapBusinessException(List<SapReturnMessage> messages) {
        super(buildMessage(messages), "SAP_BUSINESS_ERROR", false);
        this.messages = messages != null ? messages : List.of();
    }

    private static String buildMessage(List<SapReturnMessage> messages) {
        if (messages == null || messages.isEmpty()) {
            return "SAP business error occurred";
        }
        return messages.stream()
            .filter(SapReturnMessage::isError)
            .findFirst()
            .map(SapReturnMessage::getFullMessage)
            .orElse("SAP business error occurred");
    }

    /**
     * Get all error messages.
     */
    public List<SapReturnMessage> getErrorMessages() {
        return messages.stream()
            .filter(SapReturnMessage::isError)
            .toList();
    }

    /**
     * Get all warning messages.
     */
    public List<SapReturnMessage> getWarningMessages() {
        return messages.stream()
            .filter(SapReturnMessage::isWarning)
            .toList();
    }
}
