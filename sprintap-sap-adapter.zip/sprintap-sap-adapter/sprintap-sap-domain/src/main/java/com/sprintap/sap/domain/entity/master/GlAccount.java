package com.sprintap.sap.domain.entity.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * GL Account master data entity.
 * Maps to scm_mas_gl_account table.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GlAccount {

    private UUID id;
    private String glAccountCode;
    private String description;
    private String shortDescription;
    private String companyCode;
    private String chartOfAccounts;
    private String accountGroup;
    private String accountType;
    private String currencyCode;
    private String taxCategory;
    private String reconciliationAccountType;
    private LocalDate validFrom;
    private LocalDate validTo;
    private boolean active;
    private Map<String, Object> extendedAttributes;
    private String createdBy;
    private OffsetDateTime createdAt;
    private String modifiedBy;
    private OffsetDateTime modifiedAt;
}
