package com.sprintap.sap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Spring Boot application for SprintAP SAP Adapter.
 * Provides integration with SAP via Apache Camel routes.
 */
@SpringBootApplication
@EnableAsync
public class SprintapSapAdapterApplication {

    public static void main(String[] args) {
        SpringApplication.run(SprintapSapAdapterApplication.class, args);
    }
}
