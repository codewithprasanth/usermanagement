package com.sprintap.sap.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web configuration for handling static resources and common requests.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * Map favicon.ico to a 204 No Content response to suppress warnings.
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/favicon.ico")
            .setStatusCode(HttpStatus.NO_CONTENT);
    }
}
