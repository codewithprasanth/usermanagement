package com.sprintap.sap.infrastructure.sap.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sprintap.sap.domain.exception.SapAuthenticationException;
import com.sprintap.sap.infrastructure.sap.config.SapOAuthConfig;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Thread-safe OAuth2 token manager for SAP API Gateway.
 * Handles token caching and automatic refresh before expiry.
 */
@Component
@Slf4j
public class SapTokenManager {

    private final WebClient webClient;
    private final SapOAuthConfig config;

    private volatile String cachedToken;
    private volatile Instant tokenExpiry;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    public SapTokenManager(SapOAuthConfig config) {
        this.config = config;
        this.webClient = WebClient.builder()
            .baseUrl(config.getTokenUrl())
            .defaultHeader("Content-Type", MediaType.APPLICATION_FORM_URLENCODED_VALUE)
            .build();
        log.info("SapTokenManager initialized with token URL: {}", config.getTokenUrl());
    }

    /**
     * Get a valid access token. Will refresh if expired or about to expire.
     *
     * @return Valid OAuth2 access token
     * @throws SapAuthenticationException if token refresh fails
     */
    public String getAccessToken() {
        // Try read lock first for cached token
        lock.readLock().lock();
        try {
            if (isTokenValid()) {
                log.debug("Using cached SAP token");
                return cachedToken;
            }
        } finally {
            lock.readLock().unlock();
        }

        // Token invalid - acquire write lock to refresh
        lock.writeLock().lock();
        try {
            // Double-check after acquiring write lock
            if (isTokenValid()) {
                return cachedToken;
            }
            return refreshToken();
        } finally {
            lock.writeLock().unlock();
        }
    }

    /**
     * Force token refresh.
     */
    public void invalidateToken() {
        lock.writeLock().lock();
        try {
            cachedToken = null;
            tokenExpiry = null;
            log.info("SAP token invalidated");
        } finally {
            lock.writeLock().unlock();
        }
    }

    private boolean isTokenValid() {
        if (cachedToken == null || tokenExpiry == null) {
            return false;
        }
        Duration buffer = Duration.ofSeconds(config.getTokenExpiryBufferSeconds());
        return Instant.now().plus(buffer).isBefore(tokenExpiry);
    }

    private String refreshToken() {
        log.info("Refreshing SAP OAuth2 token from: {}", config.getTokenUrl());

        try {
            TokenResponse response = webClient.post()
                .body(BodyInserters.fromFormData("grant_type", "client_credentials")
                    .with("client_id", config.getClientId())
                    .with("client_secret", config.getClientSecret()))
                .retrieve()
                .bodyToMono(TokenResponse.class)
                .timeout(Duration.ofSeconds(30))
                .retryWhen(Retry.backoff(3, Duration.ofSeconds(2))
                    .filter(ex -> !(ex instanceof SapAuthenticationException))
                    .onRetryExhaustedThrow((spec, signal) ->
                        new SapAuthenticationException("Failed to refresh SAP token after retries", signal.failure())))
                .block();

            if (response == null || response.getAccessToken() == null) {
                throw new SapAuthenticationException("Empty token response from SAP");
            }

            this.cachedToken = response.getAccessToken();
            this.tokenExpiry = Instant.now().plusSeconds(response.getExpiresIn());

            log.info("SAP token refreshed successfully, expires in {} seconds", response.getExpiresIn());
            return cachedToken;

        } catch (SapAuthenticationException e) {
            throw e;
        } catch (Exception e) {
            log.error("Failed to refresh SAP token: {}", e.getMessage(), e);
            throw new SapAuthenticationException("Failed to refresh SAP token: " + e.getMessage(), e);
        }
    }

    /**
     * OAuth2 token response DTO.
     */
    @Data
    private static class TokenResponse {
        @JsonProperty("access_token")
        private String accessToken;

        @JsonProperty("expires_in")
        private long expiresIn;

        @JsonProperty("token_type")
        private String tokenType;

        @JsonProperty("scope")
        private String scope;
    }
}
