package com.sprintap.sap.infrastructure.camel.route.common;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sprintap.sap.domain.exception.SapBusinessException;
import com.sprintap.sap.domain.exception.SapCommunicationException;
import com.sprintap.sap.infrastructure.sap.client.SapApiClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Base Camel route for SAP BAPI calls.
 * Provides common patterns for SAP API communication.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class SapBapiRoute extends RouteBuilder {

    private final SapApiClient sapApiClient;
    private final ObjectMapper objectMapper;

    public static final String HEADER_BAPI_NAME = "SapBapiName";
    public static final String HEADER_COMPANY_CODE = "SapCompanyCode";
    public static final String HEADER_SYNC_ID = "SapSyncId";

    @Override
    public void configure() throws Exception {

        // Global error handler for SAP routes
        errorHandler(deadLetterChannel("direct:sap-dead-letter")
            .maximumRedeliveries(3)
            .redeliveryDelay(2000)
            .backOffMultiplier(2)
            .useExponentialBackOff()
            .retryAttemptedLogLevel(LoggingLevel.WARN)
            .logRetryAttempted(true)
            .logExhausted(true)
            .logExhaustedMessageHistory(true));

        // Exception handlers
        onException(SapBusinessException.class)
            .handled(true)
            .log(LoggingLevel.ERROR, "SAP business error: ${exception.message}")
            .setHeader("SapErrorType", constant("BUSINESS"))
            .to("direct:sap-error-handler");

        onException(SapCommunicationException.class)
            .maximumRedeliveries(3)
            .redeliveryDelay(2000)
            .backOffMultiplier(2)
            .useExponentialBackOff()
            .log(LoggingLevel.WARN, "SAP communication error (will retry): ${exception.message}");

        // Main BAPI call route
        from("direct:call-sap-bapi")
            .routeId("sap-bapi-call")
            .log("Calling SAP BAPI: ${header." + HEADER_BAPI_NAME + "}")
            .process(this::callSapBapi)
            .log("SAP BAPI call completed: ${header." + HEADER_BAPI_NAME + "}");

        // Error handler route
        from("direct:sap-error-handler")
            .routeId("sap-error-handler")
            .log(LoggingLevel.ERROR, "Handling SAP error for BAPI: ${header." + HEADER_BAPI_NAME + "}")
            .choice()
                .when(header("SapErrorType").isEqualTo("BUSINESS"))
                    .log(LoggingLevel.ERROR, "Business error - not retrying")
                    .to("direct:save-error-log")
                .otherwise()
                    .log(LoggingLevel.WARN, "Communication error - may retry")
            .end();

        // Dead letter route
        from("direct:sap-dead-letter")
            .routeId("sap-dead-letter")
            .log(LoggingLevel.ERROR, "Message sent to dead letter queue")
            .log(LoggingLevel.ERROR, "BAPI: ${header." + HEADER_BAPI_NAME + "}")
            .log(LoggingLevel.ERROR, "Error: ${exception.message}")
            .to("direct:save-error-log");

        // Error logging (placeholder - can be connected to database or queue)
        from("direct:save-error-log")
            .routeId("save-error-log")
            .log(LoggingLevel.ERROR, "Error log saved for BAPI: ${header." + HEADER_BAPI_NAME + "}");
    }

    /**
     * Processor to call SAP BAPI.
     */
    @SuppressWarnings("unchecked")
    private void callSapBapi(Exchange exchange) {
        String bapiName = exchange.getIn().getHeader(HEADER_BAPI_NAME, String.class);
        Map<String, Object> request = exchange.getIn().getBody(Map.class);

        if (bapiName == null) {
            throw new IllegalArgumentException("BAPI name header is required");
        }
        if (request == null) {
            throw new IllegalArgumentException("Request body is required");
        }

        JsonNode response = sapApiClient.callBapi(bapiName, request);
        exchange.getIn().setBody(response);
    }
}
