package com.sprintap.sap.infrastructure.camel.route.transaction;

import com.fasterxml.jackson.databind.JsonNode;
import com.sprintap.sap.domain.entity.transaction.PoAccountAssignment;
import com.sprintap.sap.domain.entity.transaction.PurchaseOrder;
import com.sprintap.sap.domain.entity.transaction.PurchaseOrderItem;
import com.sprintap.sap.infrastructure.camel.route.common.SapBapiRoute;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Camel route for purchase order operations.
 * Uses BAPI_PO_GETDETAIL1 BAPI.
 */
@Component
@Slf4j
public class PurchaseOrderRoute extends RouteBuilder {

    private static final String BAPI_GET_DETAIL = "BAPI_PO_GETDETAIL1";

    private static final DateTimeFormatter SAP_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    @Override
    public void configure() throws Exception {

        // Get PO details route
        from("direct:get-po-details")
            .routeId("po-get-details")
            .log("Getting PO details: ${header.poNumber}")
            .to("direct:prepare-po-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-po-response")
            .log("PO details retrieved: ${header.poNumber}");

        // Sync PO from SAP
        from("direct:sync-po")
            .routeId("po-sync")
            .log("Syncing PO: ${header.poNumber}")
            .to("direct:get-po-details");

        // Prepare PO request
        from("direct:prepare-po-request")
            .routeId("prepare-po-request")
            .process(this::preparePORequest);

        // Process PO response
        from("direct:process-po-response")
            .routeId("process-po-response")
            .process(this::processPOResponse);
    }

    private void preparePORequest(Exchange exchange) {
        String poNumber = exchange.getIn().getHeader("poNumber", String.class);
        boolean includeAccountAssignment = exchange.getIn().getHeader("includeAccountAssignment", true, Boolean.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        bapi.put("PURCHASEORDER", poNumber != null ? poNumber : "");
        bapi.put("ACCOUNT_ASSIGNMENT", includeAccountAssignment ? "X" : "");
        bapi.put("HEADER_TEXT", "");
        bapi.put("ITEM_TEXT", "");
        bapi.put("DELIVERY_ADDRESS", "");
        bapi.put("VERSION", "");
        bapi.put("SERVICES", "");
        bapi.put("SERIALNUMBERS", "");
        bapi.put("INVOICEPLAN", "");

        request.put(BAPI_GET_DETAIL, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_GET_DETAIL);
    }

    private void processPOResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        // SAP returns responses with format: rfc:BAPI_NAME.Response
        String responseKey = "rfc:" + BAPI_GET_DETAIL + ".Response";
        JsonNode bapiResponse = response.path(responseKey);
        if (bapiResponse.isMissingNode()) {
            bapiResponse = response.path(BAPI_GET_DETAIL);
        }

        // Map PO header
        PurchaseOrder po = new PurchaseOrder();
        po.setId(UUID.randomUUID());
        po.setPoNumber(exchange.getIn().getHeader("poNumber", String.class));

        // Parse POHEADER if available
        JsonNode poHeader = bapiResponse.path("POHEADER");
        if (!poHeader.isMissingNode()) {
            po.setCompanyCode(getText(poHeader, "COMP_CODE"));
            po.setVendorId(getText(poHeader, "VENDOR"));
            po.setDocumentType(getText(poHeader, "DOC_TYPE"));
            po.setPurchasingOrg(getText(poHeader, "PURCH_ORG"));
            po.setPurchasingGroup(getText(poHeader, "PUR_GROUP"));
            po.setCurrencyCode(getText(poHeader, "CURRENCY"));
            po.setPaymentTermsCode(getText(poHeader, "PMNTTRMS"));
            po.setIncoterms1(getText(poHeader, "INCOTERMS1"));
            po.setIncoterms2(getText(poHeader, "INCOTERMS2"));

            String docDate = getText(poHeader, "DOC_DATE");
            if (docDate != null && docDate.length() == 8) {
                po.setDocumentDate(LocalDate.parse(docDate, SAP_DATE_FORMAT));
            }

            String creatDate = getText(poHeader, "CREAT_DATE");
            if (creatDate != null && creatDate.length() == 8) {
                po.setCreatedOn(LocalDate.parse(creatDate, SAP_DATE_FORMAT));
            }

            po.setCreatedBySap(getText(poHeader, "CREATED_BY"));
        }

        // Parse POITEM
        List<PurchaseOrderItem> items = new ArrayList<>();
        JsonNode poItems = bapiResponse.path("POITEM").path("item");
        if (poItems.isArray()) {
            for (JsonNode itemNode : poItems) {
                PurchaseOrderItem item = mapToPOItem(itemNode, po.getPoNumber());
                items.add(item);
            }
        }
        po.setItems(items);

        // Parse POACCOUNT
        List<PoAccountAssignment> accountAssignments = new ArrayList<>();
        JsonNode poAccounts = bapiResponse.path("POACCOUNT").path("item");
        if (poAccounts.isArray()) {
            for (JsonNode accNode : poAccounts) {
                PoAccountAssignment acc = mapToAccountAssignment(accNode, po.getPoNumber());
                accountAssignments.add(acc);
            }
        }
        po.setAccountAssignments(accountAssignments);

        // Calculate net value
        BigDecimal netValue = items.stream()
            .filter(item -> !item.isDeleted())
            .map(PurchaseOrderItem::calculateValue)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        po.setNetValue(netValue);

        po.setLastSyncAt(OffsetDateTime.now());
        po.setCreatedBy("SAP_SYNC");
        po.setCreatedAt(OffsetDateTime.now());

        exchange.getIn().setBody(po);
        exchange.getIn().setHeader("itemCount", items.size());

        log.info("PO {} retrieved with {} items", po.getPoNumber(), items.size());
    }

    private PurchaseOrderItem mapToPOItem(JsonNode node, String poNumber) {
        PurchaseOrderItem item = new PurchaseOrderItem();
        item.setId(UUID.randomUUID());
        item.setPoNumber(poNumber);
        item.setPoItem(getText(node, "PO_ITEM"));
        item.setMaterialNumber(getText(node, "MATERIAL"));
        item.setShortText(getText(node, "SHORT_TEXT"));
        item.setPlantCode(getText(node, "PLANT"));
        item.setStorageLocation(getText(node, "STGE_LOC"));
        item.setMaterialGroup(getText(node, "MATL_GROUP"));
        item.setItemCategory(getText(node, "ITEM_CAT"));
        item.setAccountAssignmentCategory(getText(node, "ACCTASSCAT"));
        item.setTaxCode(getText(node, "TAX_CODE"));
        item.setUomCode(getText(node, "PO_UNIT"));

        // Numeric fields
        item.setQuantity(getDecimal(node, "QUANTITY"));
        item.setNetPrice(getDecimal(node, "NET_PRICE"));
        item.setPriceUnit(getDecimal(node, "PRICE_UNIT"));

        // Boolean flags
        item.setDeleted("X".equals(getText(node, "DELETE_IND")));
        item.setGrIndicator("X".equals(getText(node, "GR_IND")));
        item.setIrIndicator("X".equals(getText(node, "IR_IND")));
        item.setGrBasedIv("X".equals(getText(node, "GR_BASEDIV")));
        item.setNoMoreGr("X".equals(getText(node, "NO_MORE_GR")));
        item.setFinalInvoice("X".equals(getText(node, "FINAL_INV")));

        item.setCreatedBy("SAP_SYNC");
        item.setCreatedAt(OffsetDateTime.now());

        return item;
    }

    private PoAccountAssignment mapToAccountAssignment(JsonNode node, String poNumber) {
        PoAccountAssignment acc = new PoAccountAssignment();
        acc.setId(UUID.randomUUID());
        acc.setPoNumber(poNumber);
        acc.setPoItem(getText(node, "PO_ITEM"));
        acc.setSerialNo(getText(node, "SERIAL_NO"));
        acc.setGlAccountCode(getText(node, "GL_ACCOUNT"));
        acc.setCostCenterCode(getText(node, "COSTCENTER"));
        acc.setProfitCenterCode(getText(node, "PROFIT_CTR"));
        acc.setBusinessAreaCode(getText(node, "BUS_AREA"));
        acc.setControllingArea(getText(node, "CO_AREA"));
        acc.setWbsElement(getText(node, "WBS_ELEMENT"));
        acc.setInternalOrder(getText(node, "ORDERID"));
        acc.setAssetNumber(getText(node, "ASSET_NO"));

        acc.setQuantity(getDecimal(node, "QUANTITY"));
        acc.setDistributionPercent(getDecimal(node, "DISTR_PERC"));
        acc.setNetValue(getDecimal(node, "NET_VALUE"));

        acc.setCreatedBy("SAP_SYNC");
        acc.setCreatedAt(OffsetDateTime.now());

        return acc;
    }

    private String getText(JsonNode node, String fieldName) {
        JsonNode field = node.path(fieldName);
        if (field.isMissingNode() || field.isNull()) {
            return null;
        }
        String text = field.asText();
        return text.isBlank() ? null : text.trim();
    }

    private BigDecimal getDecimal(JsonNode node, String fieldName) {
        String value = getText(node, fieldName);
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return new BigDecimal(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
