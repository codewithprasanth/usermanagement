package com.sprintap.sap.infrastructure.sap.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sprintap.sap.domain.exception.SapBusinessException;
import com.sprintap.sap.domain.exception.SapCommunicationException;
import com.sprintap.sap.domain.valueobject.SapReturnMessage;
import com.sprintap.sap.infrastructure.sap.config.SapApiConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * SAP API client for BAPI/RFC calls.
 * Handles HTTP communication, authentication, and response parsing.
 */
@Component
@Slf4j
public class SapApiClient {

    private final WebClient webClient;
    private final SapTokenManager tokenManager;
    private final SapApiConfig config;
    private final ObjectMapper objectMapper;

    public SapApiClient(SapTokenManager tokenManager, SapApiConfig config, ObjectMapper objectMapper) {
        this.tokenManager = tokenManager;
        this.config = config;
        this.objectMapper = objectMapper;

        this.webClient = WebClient.builder()
            .baseUrl(config.getBaseUrl())
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
            .build();

        log.info("SapApiClient initialized with base URL: {}", config.getBaseUrl());
    }

    /**
     * Call SAP BAPI/RFC and return parsed JSON response.
     *
     * @param bapiName Name of the BAPI/RFC function
     * @param request Request payload
     * @return Parsed JSON response
     */
    public JsonNode callBapi(String bapiName, Map<String, Object> request) {
        log.info("Calling SAP BAPI: {}", bapiName);
        log.debug("BAPI request: {}", request);

        try {
            String token = tokenManager.getAccessToken();

            String responseBody = webClient.post()
                .uri(config.getBapiEndpoint())
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                .bodyValue(request)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response -> {
                    if (response.statusCode().value() == 401) {
                        tokenManager.invalidateToken();
                    }
                    return response.bodyToMono(String.class)
                        .map(body -> new SapCommunicationException(
                            "SAP API error " + response.statusCode() + ": " + body));
                })
                .onStatus(HttpStatusCode::is5xxServerError, response ->
                    response.bodyToMono(String.class)
                        .map(body -> new SapCommunicationException(
                            "SAP server error " + response.statusCode() + ": " + body)))
                .bodyToMono(String.class)
                .timeout(Duration.ofMillis(config.getReadTimeoutMs()))
                .retryWhen(Retry.backoff(config.getMaxRetryAttempts(), Duration.ofMillis(config.getRetryDelayMs()))
                    .filter(this::isRetryableError)
                    .onRetryExhaustedThrow((spec, signal) ->
                        new SapCommunicationException("SAP call failed after retries", signal.failure())))
                .block();

            log.debug("BAPI response: {}", responseBody);

            JsonNode responseJson = objectMapper.readTree(responseBody);
            validateBapiResponse(bapiName, responseJson);

            return responseJson;

        } catch (SapBusinessException | SapCommunicationException e) {
            throw e;
        } catch (WebClientResponseException e) {
            log.error("SAP HTTP error: {} - {}", e.getStatusCode(), e.getResponseBodyAsString());
            throw new SapCommunicationException("SAP HTTP error: " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("SAP call failed: {}", e.getMessage(), e);
            throw new SapCommunicationException("SAP call failed: " + e.getMessage(), e);
        }
    }

    /**
     * Validate BAPI response for errors.
     * SAP returns responses with format: rfc:BAPI_NAME.Response
     */
    private void validateBapiResponse(String bapiName, JsonNode response) {
        // SAP returns responses with format: rfc:BAPI_NAME.Response
        String responseKey = "rfc:" + bapiName + ".Response";
        JsonNode bapiResponse = response.path(responseKey);

        // Fallback to direct BAPI name if rfc: format not found
        if (bapiResponse.isMissingNode()) {
            bapiResponse = response.path(bapiName);
        }

        if (bapiResponse.isMissingNode()) {
            log.warn("BAPI response missing expected node: {} or {}", responseKey, bapiName);
            return;
        }

        // Check various return message node names
        JsonNode returnNode = findReturnNode(bapiResponse);
        if (returnNode == null || returnNode.isMissingNode()) {
            return;
        }

        List<SapReturnMessage> messages = parseReturnMessages(returnNode);
        List<SapReturnMessage> errors = messages.stream()
            .filter(SapReturnMessage::isError)
            .toList();

        if (!errors.isEmpty()) {
            String errorMsg = errors.stream()
                .map(SapReturnMessage::getFullMessage)
                .reduce((a, b) -> a + "; " + b)
                .orElse("SAP business error");
            log.error("SAP BAPI {} returned errors: {}", bapiName, errorMsg);
            throw new SapBusinessException(errorMsg, messages);
        }

        // Log warnings
        messages.stream()
            .filter(SapReturnMessage::isWarning)
            .forEach(msg -> log.warn("SAP warning: {}", msg.getFullMessage()));
    }

    /**
     * Find the return message node (different BAPIs use different names).
     */
    private JsonNode findReturnNode(JsonNode bapiResponse) {
        String[] possibleNames = {"RETURN", "ET_RETURN", "TT_RETURN", "E_RETURN", "BAPIRET2"};
        for (String name : possibleNames) {
            JsonNode node = bapiResponse.path(name);
            if (!node.isMissingNode()) {
                return node;
            }
        }
        return null;
    }

    /**
     * Parse return messages from response.
     */
    private List<SapReturnMessage> parseReturnMessages(JsonNode returnNode) {
        List<SapReturnMessage> messages = new ArrayList<>();

        // Handle array of items
        JsonNode items = returnNode.path("item");
        if (items.isArray()) {
            for (JsonNode item : items) {
                messages.add(parseReturnMessage(item));
            }
        } else if (!items.isMissingNode()) {
            messages.add(parseReturnMessage(items));
        } else if (returnNode.isArray()) {
            for (JsonNode item : returnNode) {
                messages.add(parseReturnMessage(item));
            }
        } else if (returnNode.isObject()) {
            messages.add(parseReturnMessage(returnNode));
        }

        return messages;
    }

    private SapReturnMessage parseReturnMessage(JsonNode node) {
        return SapReturnMessage.builder()
            .type(getTextOrNull(node, "TYPE"))
            .id(getTextOrNull(node, "ID"))
            .number(getTextOrNull(node, "NUMBER", "NUMB"))
            .message(getTextOrNull(node, "MESSAGE"))
            .logNo(getTextOrNull(node, "LOG_NO"))
            .messageV1(getTextOrNull(node, "MESSAGE_V1"))
            .messageV2(getTextOrNull(node, "MESSAGE_V2"))
            .messageV3(getTextOrNull(node, "MESSAGE_V3"))
            .messageV4(getTextOrNull(node, "MESSAGE_V4"))
            .build();
    }

    private String getTextOrNull(JsonNode node, String... fieldNames) {
        for (String fieldName : fieldNames) {
            JsonNode field = node.path(fieldName);
            if (!field.isMissingNode() && !field.asText().isBlank()) {
                return field.asText();
            }
        }
        return null;
    }

    private boolean isRetryableError(Throwable ex) {
        if (ex instanceof SapBusinessException) {
            return false; // Business errors are not retryable
        }
        if (ex instanceof WebClientResponseException wce) {
            int status = wce.getStatusCode().value();
            return status >= 500 || status == 429; // Retry server errors and rate limiting
        }
        return true; // Retry other errors (network, timeout)
    }
}
