package com.sprintap.sap.infrastructure.camel.route.transaction;

import com.fasterxml.jackson.databind.JsonNode;
import com.sprintap.sap.domain.entity.transaction.Invoice;
import com.sprintap.sap.domain.entity.transaction.InvoiceItem;
import com.sprintap.sap.domain.entity.transaction.InvoiceTax;
import com.sprintap.sap.domain.entity.transaction.InvoiceWht;
import com.sprintap.sap.infrastructure.camel.route.common.SapBapiRoute;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Camel route for invoice operations.
 * Uses ZGTFIFM_OT_INC_INVOICE_CREATE BAPI.
 */
@Component
@Slf4j
public class InvoiceRoute extends RouteBuilder {

    private static final String BAPI_CREATE = "ZGTFIFM_OT_INC_INVOICE_CREATE";
    private static final String BAPI_CHECK = "ZGTFIFM_OT_INVOICE_CHECK";
    private static final String BAPI_SIMULATE = "ZGTFIFM_MRM_SRM_INV_SIMULATE";

    private static final DateTimeFormatter SAP_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    @Override
    public void configure() throws Exception {

        // Create invoice route
        from("direct:create-invoice")
            .routeId("invoice-create")
            .log("Creating invoice for vendor: ${body.vendorId}")
            .to("direct:prepare-invoice-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-invoice-response")
            .log("Invoice created: ${header.sapDocNumber}");

        // Check invoice (duplicate check)
        from("direct:check-invoice")
            .routeId("invoice-check")
            .log("Checking invoice for duplicates")
            .to("direct:prepare-invoice-check-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-invoice-check-response");

        // Simulate invoice
        from("direct:simulate-invoice")
            .routeId("invoice-simulate")
            .log("Simulating invoice")
            .to("direct:prepare-invoice-simulate-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-invoice-simulate-response");

        // Prepare invoice creation request
        from("direct:prepare-invoice-request")
            .routeId("prepare-invoice-request")
            .process(this::prepareInvoiceRequest);

        // Process invoice creation response
        from("direct:process-invoice-response")
            .routeId("process-invoice-response")
            .process(this::processInvoiceResponse);

        // Prepare invoice check request
        from("direct:prepare-invoice-check-request")
            .routeId("prepare-invoice-check-request")
            .process(this::prepareInvoiceCheckRequest);

        // Process invoice check response
        from("direct:process-invoice-check-response")
            .routeId("process-invoice-check-response")
            .process(this::processInvoiceCheckResponse);

        // Prepare invoice simulate request
        from("direct:prepare-invoice-simulate-request")
            .routeId("prepare-invoice-simulate-request")
            .process(this::prepareInvoiceSimulateRequest);

        // Process invoice simulate response
        from("direct:process-invoice-simulate-response")
            .routeId("process-invoice-simulate-response")
            .process(this::processInvoiceSimulateResponse);
    }

    private void prepareInvoiceRequest(Exchange exchange) {
        Invoice invoice = exchange.getIn().getBody(Invoice.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        // Header data - IS_HEADERDATA
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("INVOICE_IND", invoice.isInvoiceIndicator() ? "X" : "");
        header.put("DOC_TYPE", nullToEmpty(invoice.getDocumentType()));
        header.put("DOC_DATE", formatDate(invoice.getDocumentDate()));
        header.put("PSTNG_DATE", formatDate(invoice.getPostingDate()));
        header.put("REF_DOC_NO", nullToEmpty(invoice.getReferenceDocNumber()));
        header.put("COMP_CODE", nullToEmpty(invoice.getCompanyCode()));
        header.put("CURRENCY", nullToEmpty(invoice.getCurrencyCode()));
        header.put("GROSS_AMOUNT", formatAmount(invoice.getGrossAmount()));
        header.put("PMNTTRMS", nullToEmpty(invoice.getPaymentTermsCode()));
        header.put("BLINE_DATE", formatDate(invoice.getBaselineDate()));
        header.put("BUS_AREA", nullToEmpty(invoice.getBusinessAreaCode()));
        header.put("HEADER_TXT", nullToEmpty(invoice.getHeaderText()));
        header.put("ITEM_TEXT", nullToEmpty(invoice.getItemText()));
        header.put("PYMT_METH", nullToEmpty(invoice.getPaymentMethod()));
        header.put("PMNT_BLOCK", nullToEmpty(invoice.getPaymentBlock()));
        header.put("DE_CRE_IND", nullToEmpty(invoice.getDebitCreditIndicator()));
        header.put("PERSON_EXT", nullToEmpty(invoice.getPersonExternal()));

        // Add exchange rate if provided
        if (invoice.getExchangeRate() != null) {
            header.put("EXCH_RATE", formatAmount(invoice.getExchangeRate()));
        }

        bapi.put("IS_HEADERDATA", header);

        // Item data - IT_ITEMDATA
        List<Map<String, Object>> items = new ArrayList<>();
        if (invoice.getItems() != null) {
            for (InvoiceItem item : invoice.getItems()) {
                Map<String, Object> itemMap = new LinkedHashMap<>();
                itemMap.put("INVOICE_DOC_ITEM", nullToEmpty(item.getInvoiceDocItem()));
                itemMap.put("PO_NUMBER", nullToEmpty(item.getPoNumber()));
                itemMap.put("PO_ITEM", nullToEmpty(item.getPoItem()));
                itemMap.put("REF_DOC", nullToEmpty(item.getReferenceDocument()));
                itemMap.put("REF_DOC_YEAR", nullToEmpty(item.getReferenceDocYear()));
                itemMap.put("REF_DOC_IT", nullToEmpty(item.getReferenceDocItem()));
                itemMap.put("SHEET_NO", nullToEmpty(item.getEntrySheetNumber()));
                itemMap.put("SHEET_ITEM", nullToEmpty(item.getEntrySheetItem()));
                itemMap.put("TAX_CODE", nullToEmpty(item.getTaxCode()));
                itemMap.put("TAXJURCODE", nullToEmpty(item.getTaxJurisdictionCode()));
                itemMap.put("ITEM_AMOUNT", formatAmount(item.getItemAmount()));
                itemMap.put("QUANTITY", formatQuantity(item.getQuantity()));
                itemMap.put("PO_UNIT", nullToEmpty(item.getUomCode()));
                itemMap.put("ITEM_TEXT", nullToEmpty(item.getItemText()));
                itemMap.put("FINAL_INV", item.isFinalInvoice() ? "X" : "");
                items.add(itemMap);
            }
        }
        bapi.put("IT_ITEMDATA", Map.of("item", items));

        // Tax data - IT_TAXDATA
        List<Map<String, Object>> taxes = new ArrayList<>();
        if (invoice.getTaxes() != null) {
            for (InvoiceTax tax : invoice.getTaxes()) {
                Map<String, Object> taxMap = new LinkedHashMap<>();
                taxMap.put("TAX_CODE", nullToEmpty(tax.getTaxCode()));
                taxMap.put("TAXJURCODE", nullToEmpty(tax.getTaxJurisdictionCode()));
                taxMap.put("TAX_AMOUNT", formatAmount(tax.getTaxAmount()));
                taxMap.put("TAX_BASE_AMOUNT", formatAmount(tax.getTaxBaseAmount()));
                taxMap.put("COND_TYPE", nullToEmpty(tax.getConditionType()));
                taxes.add(taxMap);
            }
        }
        bapi.put("IT_TAXDATA", Map.of("item", taxes));

        // Withholding tax data - IT_WITHTAXDATA
        List<Map<String, Object>> whtData = new ArrayList<>();
        if (invoice.getWithholdingTaxes() != null) {
            for (InvoiceWht wht : invoice.getWithholdingTaxes()) {
                Map<String, Object> whtMap = new LinkedHashMap<>();
                whtMap.put("SPLIT_KEY", nullToEmpty(wht.getSplitKey()));
                whtMap.put("WI_TAX_TYPE", nullToEmpty(wht.getWhtType()));
                whtMap.put("WI_TAX_CODE", nullToEmpty(wht.getWhtCode()));
                whtMap.put("WI_TAX_BASE", formatAmount(wht.getWhtBaseAmount()));
                whtMap.put("WI_TAX_AMT", formatAmount(wht.getWhtAmount()));
                whtMap.put("WI_TAX_WITHHELD_AMT", formatAmount(wht.getWhtWithheldAmount()));
                whtData.add(whtMap);
            }
        }
        bapi.put("IT_WITHTAXDATA", Map.of("item", whtData));

        request.put(BAPI_CREATE, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_CREATE);
        exchange.getIn().setHeader("invoice", invoice);
    }

    private void processInvoiceResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        Invoice invoice = exchange.getIn().getHeader("invoice", Invoice.class);

        // SAP returns responses with format: rfc:BAPI_NAME.Response
        JsonNode bapiResponse = getBapiResponse(response, BAPI_CREATE);

        // Get returned document number
        String docNumber = getText(bapiResponse, "E_INVOICEDOCNUMBER", "INV_DOC_NO");
        String fiscalYear = getText(bapiResponse, "E_FISCALYEAR", "GJAHR");

        if (docNumber != null && !docNumber.isBlank()) {
            invoice.markPosted(docNumber, fiscalYear);
            log.info("Invoice posted successfully: {}/{}", docNumber, fiscalYear);
        }

        exchange.getIn().setBody(invoice);
        exchange.getIn().setHeader("sapDocNumber", docNumber);
        exchange.getIn().setHeader("sapFiscalYear", fiscalYear);
    }

    private void prepareInvoiceCheckRequest(Exchange exchange) {
        Invoice invoice = exchange.getIn().getBody(Invoice.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        bapi.put("I_COMP_CODE", nullToEmpty(invoice.getCompanyCode()));
        bapi.put("I_VENDOR", nullToEmpty(invoice.getVendorId()));
        bapi.put("I_REF_DOC_NO", nullToEmpty(invoice.getReferenceDocNumber()));
        bapi.put("I_AMOUNT", formatAmount(invoice.getGrossAmount()));
        bapi.put("I_CURRENCY", nullToEmpty(invoice.getCurrencyCode()));
        bapi.put("I_DOC_DATE", formatDate(invoice.getDocumentDate()));

        request.put(BAPI_CHECK, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_CHECK);
    }

    private void processInvoiceCheckResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        JsonNode bapiResponse = getBapiResponse(response, BAPI_CHECK);

        boolean isDuplicate = false;
        String existingDoc = null;

        // Check for duplicate indicator
        String dupFlag = getText(bapiResponse, "E_DUPLICATE", "DUPLICATE");
        if ("X".equals(dupFlag)) {
            isDuplicate = true;
            existingDoc = getText(bapiResponse, "E_EXISTING_DOC", "BELNR");
        }

        Map<String, Object> result = new HashMap<>();
        result.put("isDuplicate", isDuplicate);
        result.put("existingDocument", existingDoc);

        exchange.getIn().setBody(result);
        exchange.getIn().setHeader("isDuplicate", isDuplicate);
    }

    private void prepareInvoiceSimulateRequest(Exchange exchange) {
        Invoice invoice = exchange.getIn().getBody(Invoice.class);
        // Similar to create request but with simulation flag
        prepareInvoiceRequest(exchange);
        // Override BAPI name
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_SIMULATE);
    }

    private void processInvoiceSimulateResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        JsonNode bapiResponse = getBapiResponse(response, BAPI_SIMULATE);

        Map<String, Object> result = new HashMap<>();
        result.put("simulationSuccess", true);

        // Extract simulation results (calculated tax, etc.)
        JsonNode taxData = bapiResponse.path("ET_TAX");
        if (!taxData.isMissingNode()) {
            result.put("calculatedTax", taxData);
        }

        exchange.getIn().setBody(result);
    }

    // Utility methods
    private JsonNode getBapiResponse(JsonNode response, String bapiName) {
        // SAP returns responses with format: rfc:BAPI_NAME.Response
        String responseKey = "rfc:" + bapiName + ".Response";
        JsonNode bapiResponse = response.path(responseKey);
        if (bapiResponse.isMissingNode()) {
            bapiResponse = response.path(bapiName);
        }
        return bapiResponse;
    }

    private String formatDate(LocalDate date) {
        return date != null ? date.format(SAP_DATE_FORMAT) : "";
    }

    private String formatAmount(BigDecimal amount) {
        return amount != null ? amount.toPlainString() : "";
    }

    private String formatQuantity(BigDecimal qty) {
        return qty != null ? qty.toPlainString() : "";
    }

    private String nullToEmpty(String value) {
        return value != null ? value : "";
    }

    private String getText(JsonNode node, String... fieldNames) {
        for (String fieldName : fieldNames) {
            JsonNode field = node.path(fieldName);
            if (!field.isMissingNode() && !field.asText().isBlank()) {
                return field.asText().trim();
            }
        }
        return null;
    }
}
