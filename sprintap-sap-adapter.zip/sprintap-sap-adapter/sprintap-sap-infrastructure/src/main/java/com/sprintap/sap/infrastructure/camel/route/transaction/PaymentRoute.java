package com.sprintap.sap.infrastructure.camel.route.transaction;

import com.fasterxml.jackson.databind.JsonNode;
import com.sprintap.sap.domain.entity.transaction.Payment;
import com.sprintap.sap.domain.entity.transaction.PaymentItem;
import com.sprintap.sap.infrastructure.camel.route.common.SapBapiRoute;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Camel route for payment operations.
 * Uses ZGTFIFM_F48_POST BAPI for payment posting.
 */
@Component
@Slf4j
public class PaymentRoute extends RouteBuilder {

    private static final String BAPI_POST = "ZGTFIFM_F48_POST";
    private static final String BAPI_DETAILS = "ZGTFIFM_OT_PAYMENT_DET_RFC";

    private static final DateTimeFormatter SAP_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    @Override
    public void configure() throws Exception {

        // Post payment route
        from("direct:post-payment")
            .routeId("payment-post")
            .log("Posting payment for company: ${body.companyCode}")
            .to("direct:prepare-payment-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-payment-response")
            .log("Payment posted: ${header.sapDocNumber}");

        // Get payment details route
        from("direct:get-payment-details")
            .routeId("payment-details")
            .log("Getting payment details: ${header.documentNumber}")
            .to("direct:prepare-payment-details-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-payment-details-response");

        // Prepare payment request
        from("direct:prepare-payment-request")
            .routeId("prepare-payment-request")
            .process(this::preparePaymentRequest);

        // Process payment response
        from("direct:process-payment-response")
            .routeId("process-payment-response")
            .process(this::processPaymentResponse);

        // Prepare payment details request
        from("direct:prepare-payment-details-request")
            .routeId("prepare-payment-details-request")
            .process(this::preparePaymentDetailsRequest);

        // Process payment details response
        from("direct:process-payment-details-response")
            .routeId("process-payment-details-response")
            .process(this::processPaymentDetailsResponse);
    }

    private void preparePaymentRequest(Exchange exchange) {
        Payment payment = exchange.getIn().getBody(Payment.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        // Header - IM_HEADER
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("COMP_CODE", nullToEmpty(payment.getCompanyCode()));
        header.put("DOC_DATE", formatDate(payment.getDocumentDate()));
        header.put("PSTNG_DATE", formatDate(payment.getPostingDate()));
        header.put("DOC_TYPE", nullToEmpty(payment.getDocumentType()));
        header.put("FIS_PERIOD", nullToEmpty(payment.getFiscalPeriod()));
        header.put("REF_DOC_NO", nullToEmpty(payment.getReferenceDocNumber()));
        header.put("HEADER_TXT", nullToEmpty(payment.getHeaderText()));
        header.put("CURRENCY", nullToEmpty(payment.getCurrencyCode()));
        bapi.put("IM_HEADER", header);

        // Vendor items - TT_VENDOR_ITEM
        List<Map<String, Object>> vendorItems = new ArrayList<>();
        // Bank items - TT_BANK_ITEM
        List<Map<String, Object>> bankItems = new ArrayList<>();

        if (payment.getItems() != null) {
            for (PaymentItem item : payment.getItems()) {
                if (item.isVendorItem()) {
                    Map<String, Object> vendorItem = new LinkedHashMap<>();
                    vendorItem.put("VENDOR_NO", nullToEmpty(item.getVendorId()));
                    vendorItem.put("BUS_AREA", nullToEmpty(item.getBusinessAreaCode()));
                    vendorItem.put("PYMT_METH", nullToEmpty(item.getPaymentMethod()));
                    vendorItem.put("ITEM_TEXT", nullToEmpty(item.getItemText()));
                    vendorItem.put("W_TAX_CODE", nullToEmpty(item.getWhtCode()));
                    vendorItem.put("TAX_CODE", nullToEmpty(item.getTaxCode()));
                    vendorItem.put("PROFIT_CTR", nullToEmpty(item.getProfitCenterCode()));
                    vendorItem.put("PO_NUMBER", nullToEmpty(item.getPoNumber()));
                    vendorItem.put("PO_ITEM", nullToEmpty(item.getPoItem()));
                    vendorItem.put("SP_GL_IND", nullToEmpty(item.getSpecialGlIndicator()));
                    vendorItem.put("AMT_DOCCUR", formatAmount(item.getAmount()));
                    vendorItem.put("ALLOC_NMBR", nullToEmpty(item.getAllocationNumber()));
                    vendorItems.add(vendorItem);
                } else if (item.isBankItem()) {
                    Map<String, Object> bankItem = new LinkedHashMap<>();
                    bankItem.put("GL_ACCOUNT", nullToEmpty(item.getGlAccountCode()));
                    bankItem.put("BUS_AREA", nullToEmpty(item.getBusinessAreaCode()));
                    bankItem.put("VALUE_DATE", formatDate(item.getValueDate()));
                    bankItem.put("PROFIT_CTR", nullToEmpty(item.getProfitCenterCode()));
                    bankItem.put("AMT_DOCCUR", formatAmount(item.getAmount()));
                    bankItems.add(bankItem);
                }
            }
        }

        bapi.put("TT_VENDOR_ITEM", Map.of("item", vendorItems));
        bapi.put("TT_BANK_ITEM", Map.of("item", bankItems));

        // Empty clearing docs for now
        bapi.put("TT_CLEARDOCS", Map.of("item", new ArrayList<>()));

        request.put(BAPI_POST, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_POST);
        exchange.getIn().setHeader("payment", payment);
    }

    private void processPaymentResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        Payment payment = exchange.getIn().getHeader("payment", Payment.class);

        JsonNode bapiResponse = getBapiResponse(response, BAPI_POST);

        // Get returned document number
        String docNumber = getText(bapiResponse, "E_BELNR", "BELNR");
        String fiscalYear = getText(bapiResponse, "E_GJAHR", "GJAHR");

        if (docNumber != null && !docNumber.isBlank()) {
            payment.markPosted(docNumber, fiscalYear);
            log.info("Payment posted successfully: {}/{}", docNumber, fiscalYear);
        }

        exchange.getIn().setBody(payment);
        exchange.getIn().setHeader("sapDocNumber", docNumber);
        exchange.getIn().setHeader("sapFiscalYear", fiscalYear);
    }

    private void preparePaymentDetailsRequest(Exchange exchange) {
        String companyCode = exchange.getIn().getHeader("companyCode", String.class);
        String documentNumber = exchange.getIn().getHeader("documentNumber", String.class);
        String fiscalYear = exchange.getIn().getHeader("fiscalYear", String.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        bapi.put("I_BUKRS", nullToEmpty(companyCode));
        bapi.put("I_BELNR", nullToEmpty(documentNumber));
        bapi.put("I_GJAHR", nullToEmpty(fiscalYear));

        request.put(BAPI_DETAILS, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_DETAILS);
    }

    private void processPaymentDetailsResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        JsonNode bapiResponse = getBapiResponse(response, BAPI_DETAILS);

        // Map response to Payment entity
        Payment payment = new Payment();
        payment.setId(UUID.randomUUID());
        payment.setDocumentNumber(getText(bapiResponse, "E_BELNR", "BELNR"));
        payment.setCompanyCode(getText(bapiResponse, "E_BUKRS", "BUKRS"));
        payment.setFiscalYear(getText(bapiResponse, "E_GJAHR", "GJAHR"));

        // Parse document date
        String docDate = getText(bapiResponse, "E_BLDAT", "BLDAT");
        if (docDate != null && docDate.length() == 8) {
            payment.setDocumentDate(LocalDate.parse(docDate, SAP_DATE_FORMAT));
        }

        String postDate = getText(bapiResponse, "E_BUDAT", "BUDAT");
        if (postDate != null && postDate.length() == 8) {
            payment.setPostingDate(LocalDate.parse(postDate, SAP_DATE_FORMAT));
        }

        exchange.getIn().setBody(payment);
    }

    // Utility methods
    private JsonNode getBapiResponse(JsonNode response, String bapiName) {
        // SAP returns responses with format: rfc:BAPI_NAME.Response
        String responseKey = "rfc:" + bapiName + ".Response";
        JsonNode bapiResponse = response.path(responseKey);
        if (bapiResponse.isMissingNode()) {
            bapiResponse = response.path(bapiName);
        }
        return bapiResponse;
    }

    private String formatDate(LocalDate date) {
        return date != null ? date.format(SAP_DATE_FORMAT) : "";
    }

    private String formatAmount(BigDecimal amount) {
        return amount != null ? amount.toPlainString() : "";
    }

    private String nullToEmpty(String value) {
        return value != null ? value : "";
    }

    private String getText(JsonNode node, String... fieldNames) {
        for (String fieldName : fieldNames) {
            JsonNode field = node.path(fieldName);
            if (!field.isMissingNode() && !field.asText().isBlank()) {
                return field.asText().trim();
            }
        }
        return null;
    }
}
