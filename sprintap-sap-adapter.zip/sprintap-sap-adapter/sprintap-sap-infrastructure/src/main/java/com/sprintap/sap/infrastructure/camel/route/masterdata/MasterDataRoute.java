package com.sprintap.sap.infrastructure.camel.route.masterdata;

import com.fasterxml.jackson.databind.JsonNode;
import com.sprintap.sap.domain.entity.master.CostCenter;
import com.sprintap.sap.domain.entity.master.GlAccount;
import com.sprintap.sap.domain.entity.master.PaymentTerms;
import com.sprintap.sap.domain.entity.master.WhtCode;
import com.sprintap.sap.infrastructure.camel.route.common.SapBapiRoute;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Camel routes for master data synchronization from SAP.
 * Handles cost centers, GL accounts, WHT codes, and payment terms.
 */
@Component
@Slf4j
public class MasterDataRoute extends RouteBuilder {

    private static final String BAPI_COST_CENTER = "ZGTFIFM_COST_CENTER_DETAILS";
    private static final String BAPI_GL_ACCOUNT = "ZGTFIFM_OT_GL_DET_RFC";
    private static final String BAPI_WHT_CODE = "ZGTFIFM_OT_WHT_MASTER";
    private static final String BAPI_PAYMENT_TERMS = "ZGTFI_TERMS_OF_PAYMENT_PROP";

    private static final DateTimeFormatter SAP_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter SAP_DATE_HYPHEN = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    public void configure() throws Exception {

        // ===== Cost Center Routes =====
        from("direct:sync-cost-centers")
            .routeId("cost-center-sync")
            .log("Starting cost center sync for company: ${header.companyCode}")
            .to("direct:prepare-cost-center-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-cost-center-response")
            .log("Cost center sync completed: ${header.syncCount} records");

        from("direct:prepare-cost-center-request")
            .routeId("prepare-cost-center-request")
            .process(this::prepareCostCenterRequest);

        from("direct:process-cost-center-response")
            .routeId("process-cost-center-response")
            .process(this::processCostCenterResponse);

        // ===== GL Account Routes =====
        from("direct:sync-gl-accounts")
            .routeId("gl-account-sync")
            .log("Starting GL account sync for company: ${header.companyCode}")
            .to("direct:prepare-gl-account-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-gl-account-response")
            .log("GL account sync completed: ${header.syncCount} records");

        from("direct:prepare-gl-account-request")
            .routeId("prepare-gl-account-request")
            .process(this::prepareGlAccountRequest);

        from("direct:process-gl-account-response")
            .routeId("process-gl-account-response")
            .process(this::processGlAccountResponse);

        // ===== WHT Code Routes =====
        from("direct:sync-wht-codes")
            .routeId("wht-code-sync")
            .log("Starting WHT code sync for company: ${header.companyCode}, country: ${header.countryCode}")
            .to("direct:prepare-wht-code-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-wht-code-response")
            .log("WHT code sync completed: ${header.syncCount} records");

        from("direct:prepare-wht-code-request")
            .routeId("prepare-wht-code-request")
            .process(this::prepareWhtCodeRequest);

        from("direct:process-wht-code-response")
            .routeId("process-wht-code-response")
            .process(this::processWhtCodeResponse);

        // ===== Payment Terms Routes =====
        from("direct:sync-payment-terms")
            .routeId("payment-terms-sync")
            .log("Starting payment terms sync for company: ${header.companyCode}")
            .to("direct:prepare-payment-terms-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-payment-terms-response")
            .log("Payment terms sync completed: ${header.syncCount} records");

        from("direct:prepare-payment-terms-request")
            .routeId("prepare-payment-terms-request")
            .process(this::preparePaymentTermsRequest);

        from("direct:process-payment-terms-response")
            .routeId("process-payment-terms-response")
            .process(this::processPaymentTermsResponse);
    }

    // ===== Cost Center Methods =====
    private void prepareCostCenterRequest(Exchange exchange) {
        String companyCode = exchange.getIn().getHeader("companyCode", String.class);
        String fromDate = exchange.getIn().getHeader("fromDate", String.class);
        String toDate = exchange.getIn().getHeader("toDate", String.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        bapi.put("IV_BUKRS", nullToEmpty(companyCode));
        bapi.put("IV_FROM_DATE", fromDate != null ? Integer.parseInt(fromDate.replace("-", "")) : 20240101);
        bapi.put("IV_TO_DATE", toDate != null ? Integer.parseInt(toDate.replace("-", "")) : 20991231);

        request.put(BAPI_COST_CENTER, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_COST_CENTER);
    }

    private void processCostCenterResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        JsonNode bapiResponse = getBapiResponse(response, BAPI_COST_CENTER);

        List<CostCenter> costCenters = new ArrayList<>();
        JsonNode items = bapiResponse.path("ET_COST_CENTER").path("item");

        if (items.isArray()) {
            for (JsonNode item : items) {
                CostCenter cc = mapToCostCenter(item);
                costCenters.add(cc);
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("costCenters", costCenters);

        exchange.getIn().setBody(result);
        exchange.getIn().setHeader("syncCount", costCenters.size());
        log.info("Processed {} cost centers", costCenters.size());
    }

    private CostCenter mapToCostCenter(JsonNode node) {
        CostCenter cc = new CostCenter();
        cc.setId(UUID.randomUUID());
        cc.setCostCenterCode(getText(node, "KOSTL"));
        cc.setDescription(getText(node, "LTEXT"));
        cc.setCompanyCode(getText(node, "BUKRS"));
        cc.setControllingArea(getText(node, "KOKRS"));
        cc.setResponsiblePerson(getText(node, "VERAK"));
        cc.setBusinessAreaCode(getText(node, "GSBER"));
        cc.setCurrencyCode(getText(node, "WAERS"));
        cc.setProfitCenterCode(getText(node, "PRCTR"));

        // Parse dates
        String validTo = getText(node, "DATBI");
        if (validTo != null) {
            cc.setValidTo(parseDate(validTo));
        }
        String validFrom = getText(node, "DATAB");
        if (validFrom != null) {
            cc.setValidFrom(parseDate(validFrom));
        }

        cc.setActive(true);
        cc.setCreatedBy("SAP_SYNC");
        cc.setCreatedAt(OffsetDateTime.now());

        return cc;
    }

    // ===== GL Account Methods =====
    private void prepareGlAccountRequest(Exchange exchange) {
        String companyCode = exchange.getIn().getHeader("companyCode", String.class);
        String fromDate = exchange.getIn().getHeader("fromDate", String.class);
        String toDate = exchange.getIn().getHeader("toDate", String.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        bapi.put("IV_BUKRS", nullToEmpty(companyCode));
        bapi.put("IV_FROM_DATE", fromDate != null ? Integer.parseInt(fromDate.replace("-", "")) : 20240101);
        bapi.put("IV_TO_DATE", toDate != null ? Integer.parseInt(toDate.replace("-", "")) : 20991231);

        request.put(BAPI_GL_ACCOUNT, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_GL_ACCOUNT);
    }

    private void processGlAccountResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        JsonNode bapiResponse = getBapiResponse(response, BAPI_GL_ACCOUNT);

        List<GlAccount> glAccounts = new ArrayList<>();
        JsonNode items = bapiResponse.path("ET_GL_DET").path("item");

        if (items.isArray()) {
            for (JsonNode item : items) {
                GlAccount gl = mapToGlAccount(item);
                glAccounts.add(gl);
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("glAccounts", glAccounts);

        exchange.getIn().setBody(result);
        exchange.getIn().setHeader("syncCount", glAccounts.size());
        log.info("Processed {} GL accounts", glAccounts.size());
    }

    private GlAccount mapToGlAccount(JsonNode node) {
        GlAccount gl = new GlAccount();
        gl.setId(UUID.randomUUID());
        gl.setGlAccountCode(getText(node, "SAKNR", "GL_ACCOUNT"));
        gl.setDescription(getText(node, "TXT50", "DESCRIPTION"));
        gl.setShortDescription(getText(node, "TXT20", "SHORT_DESC"));
        gl.setCompanyCode(getText(node, "BUKRS"));
        gl.setChartOfAccounts(getText(node, "KTOPL"));
        gl.setAccountGroup(getText(node, "KTOKS"));
        gl.setAccountType(getText(node, "XBILK"));
        gl.setCurrencyCode(getText(node, "WAERS"));
        gl.setTaxCategory(getText(node, "MWSKZ"));

        gl.setActive(true);
        gl.setCreatedBy("SAP_SYNC");
        gl.setCreatedAt(OffsetDateTime.now());

        return gl;
    }

    // ===== WHT Code Methods =====
    private void prepareWhtCodeRequest(Exchange exchange) {
        String companyCode = exchange.getIn().getHeader("companyCode", String.class);
        String countryCode = exchange.getIn().getHeader("countryCode", String.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        bapi.put("IV_BUKRS", nullToEmpty(companyCode));
        bapi.put("IV_LAND1", nullToEmpty(countryCode));

        request.put(BAPI_WHT_CODE, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_WHT_CODE);
    }

    private void processWhtCodeResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        JsonNode bapiResponse = getBapiResponse(response, BAPI_WHT_CODE);

        List<WhtCode> whtCodes = new ArrayList<>();
        JsonNode items = bapiResponse.path("ET_WHT_MASTER").path("item");

        if (items.isArray()) {
            for (JsonNode item : items) {
                WhtCode wht = mapToWhtCode(item);
                whtCodes.add(wht);
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("whtCodes", whtCodes);

        exchange.getIn().setBody(result);
        exchange.getIn().setHeader("syncCount", whtCodes.size());
        log.info("Processed {} WHT codes", whtCodes.size());
    }

    private WhtCode mapToWhtCode(JsonNode node) {
        WhtCode wht = new WhtCode();
        wht.setId(UUID.randomUUID());
        wht.setWhtCode(getText(node, "QSATZ", "WHT_CODE"));
        wht.setWhtType(getText(node, "WITHT", "WHT_TYPE"));
        wht.setDescription(getText(node, "QTEXT", "DESCRIPTION"));
        wht.setCountryCode(getText(node, "LAND1"));
        wht.setCompanyCode(getText(node, "BUKRS"));

        // Parse rates
        String whtRate = getText(node, "QPROZ", "WHT_RATE");
        if (whtRate != null) {
            try {
                wht.setWhtRate(new BigDecimal(whtRate));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        wht.setActive(true);
        wht.setCreatedBy("SAP_SYNC");
        wht.setCreatedAt(OffsetDateTime.now());

        return wht;
    }

    // ===== Payment Terms Methods =====
    private void preparePaymentTermsRequest(Exchange exchange) {
        String companyCode = exchange.getIn().getHeader("companyCode", String.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapi = new LinkedHashMap<>();

        bapi.put("IV_BUKRS", nullToEmpty(companyCode));

        request.put(BAPI_PAYMENT_TERMS, bapi);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_PAYMENT_TERMS);
    }

    private void processPaymentTermsResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        JsonNode bapiResponse = getBapiResponse(response, BAPI_PAYMENT_TERMS);

        List<PaymentTerms> paymentTerms = new ArrayList<>();
        JsonNode items = bapiResponse.path("ET_TERMS_OF_PAYMENT").path("item");

        if (items.isArray()) {
            for (JsonNode item : items) {
                PaymentTerms pt = mapToPaymentTerms(item);
                paymentTerms.add(pt);
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("paymentTerms", paymentTerms);

        exchange.getIn().setBody(result);
        exchange.getIn().setHeader("syncCount", paymentTerms.size());
        log.info("Processed {} payment terms", paymentTerms.size());
    }

    private PaymentTerms mapToPaymentTerms(JsonNode node) {
        PaymentTerms pt = new PaymentTerms();
        pt.setId(UUID.randomUUID());
        pt.setPaymentTermsCode(getText(node, "ZTERM"));
        pt.setDescription(getText(node, "TEXT1", "DESCRIPTION"));
        pt.setCompanyCode(getText(node, "BUKRS"));

        // Parse numeric fields
        String netDays = getText(node, "ZTAG1", "NET_DAYS");
        if (netDays != null) {
            try {
                pt.setNetDays(Integer.parseInt(netDays));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        String discount1Days = getText(node, "ZTAG2");
        if (discount1Days != null) {
            try {
                pt.setDiscount1Days(Integer.parseInt(discount1Days));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        String discount1Percent = getText(node, "ZPRZ1");
        if (discount1Percent != null) {
            try {
                pt.setDiscount1Percent(new BigDecimal(discount1Percent));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        String discount2Days = getText(node, "ZTAG3");
        if (discount2Days != null) {
            try {
                pt.setDiscount2Days(Integer.parseInt(discount2Days));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        String discount2Percent = getText(node, "ZPRZ2");
        if (discount2Percent != null) {
            try {
                pt.setDiscount2Percent(new BigDecimal(discount2Percent));
            } catch (NumberFormatException e) {
                // ignore
            }
        }

        pt.setActive(true);
        pt.setCreatedBy("SAP_SYNC");
        pt.setCreatedAt(OffsetDateTime.now());

        return pt;
    }

    // ===== Utility Methods =====
    private JsonNode getBapiResponse(JsonNode response, String bapiName) {
        String responseKey = "rfc:" + bapiName + ".Response";
        JsonNode bapiResponse = response.path(responseKey);
        if (bapiResponse.isMissingNode()) {
            bapiResponse = response.path(bapiName);
        }
        return bapiResponse;
    }

    private String nullToEmpty(String value) {
        return value != null ? value : "";
    }

    private String getText(JsonNode node, String... fieldNames) {
        for (String fieldName : fieldNames) {
            JsonNode field = node.path(fieldName);
            if (!field.isMissingNode() && !field.isNull() && !field.asText().isBlank()) {
                return field.asText().trim();
            }
        }
        return null;
    }

    private LocalDate parseDate(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) {
            return null;
        }
        try {
            if (dateStr.contains("-")) {
                return LocalDate.parse(dateStr, SAP_DATE_HYPHEN);
            } else if (dateStr.length() == 8) {
                return LocalDate.parse(dateStr, SAP_DATE_FORMAT);
            }
        } catch (Exception e) {
            log.warn("Failed to parse date: {}", dateStr);
        }
        return null;
    }
}
