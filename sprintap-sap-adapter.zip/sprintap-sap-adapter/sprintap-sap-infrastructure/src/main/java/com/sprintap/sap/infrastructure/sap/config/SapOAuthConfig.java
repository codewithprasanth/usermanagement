package com.sprintap.sap.infrastructure.sap.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * SAP OAuth2 configuration properties.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "sap.oauth2")
public class SapOAuthConfig {

    /**
     * OAuth2 token endpoint URL.
     * Default: https://olamagri-qas.test.apimanagement.ap11.hana.ondemand.com/oauth/token
     */
    private String tokenUrl;

    /**
     * OAuth2 client ID.
     */
    private String clientId;

    /**
     * OAuth2 client secret.
     */
    private String clientSecret;

    /**
     * Buffer time in seconds before token expiry to trigger refresh.
     * Default: 300 (5 minutes)
     */
    private int tokenExpiryBufferSeconds = 300;
}
