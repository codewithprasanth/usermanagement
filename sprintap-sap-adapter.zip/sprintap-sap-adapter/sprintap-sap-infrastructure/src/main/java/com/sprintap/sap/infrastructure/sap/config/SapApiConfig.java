package com.sprintap.sap.infrastructure.sap.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * SAP API configuration properties.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "sap.api")
public class SapApiConfig {

    /**
     * SAP API base URL.
     * Default: https://olamagri-qas.test.apimanagement.ap11.hana.ondemand.com
     */
    private String baseUrl;

    /**
     * BAPI endpoint path.
     * Default: /OA_RISE_BAPI
     */
    private String bapiEndpoint = "/OA_RISE_BAPI";

    /**
     * Connection timeout in milliseconds.
     */
    private int connectionTimeoutMs = 10000;

    /**
     * Read timeout in milliseconds.
     */
    private int readTimeoutMs = 60000;

    /**
     * Maximum retry attempts for failed requests.
     */
    private int maxRetryAttempts = 3;

    /**
     * Initial retry delay in milliseconds.
     */
    private int retryDelayMs = 2000;

    /**
     * Get full BAPI URL.
     */
    public String getBapiUrl() {
        return baseUrl + bapiEndpoint;
    }
}
