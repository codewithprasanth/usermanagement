package com.sprintap.sap.infrastructure.camel.route.masterdata;

import com.fasterxml.jackson.databind.JsonNode;
import com.sprintap.sap.domain.entity.master.Vendor;
import com.sprintap.sap.domain.entity.master.VendorBank;
import com.sprintap.sap.domain.entity.master.VendorCompany;
import com.sprintap.sap.infrastructure.camel.route.common.SapBapiRoute;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.*;

/**
 * Camel route for vendor master data synchronization.
 * Uses ZGTMMFM_OT_VENDOR_DETAILS BAPI.
 */
@Component
@Slf4j
public class VendorSyncRoute extends RouteBuilder {

    private static final String BAPI_NAME = "ZGTMMFM_OT_VENDOR_DETAILS";

    @Override
    public void configure() throws Exception {

        // Main vendor sync route
        from("direct:sync-vendor")
            .routeId("vendor-sync")
            .log("Starting vendor sync for company: ${header.companyCode}")
            .to("direct:prepare-vendor-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-vendor-response")
            .log("Vendor sync completed: ${header.syncCount} records processed");

        // Prepare SAP request
        from("direct:prepare-vendor-request")
            .routeId("prepare-vendor-request")
            .process(this::prepareVendorRequest);

        // Process response and map to domain entities
        from("direct:process-vendor-response")
            .routeId("process-vendor-response")
            .process(this::processVendorResponse);

        // Sync single vendor
        from("direct:sync-single-vendor")
            .routeId("sync-single-vendor")
            .log("Syncing single vendor: ${header.vendorId}")
            .to("direct:prepare-vendor-request")
            .to("direct:call-sap-bapi")
            .to("direct:process-vendor-response");
    }

    private void prepareVendorRequest(Exchange exchange) {
        String companyCode = exchange.getIn().getHeader("companyCode", String.class);
        String vendorId = exchange.getIn().getHeader("vendorId", String.class);
        String vendorIdTo = exchange.getIn().getHeader("vendorIdTo", String.class);
        String vendorAccountGroup = exchange.getIn().getHeader("vendorAccountGroup", String.class);

        Map<String, Object> request = new LinkedHashMap<>();
        Map<String, Object> bapiParams = new LinkedHashMap<>();

        bapiParams.put("IV_BUKRS", companyCode != null ? companyCode : "");
        bapiParams.put("IV_INDICATOR", "X"); // Return detailed data
        bapiParams.put("IV_LIFNR", vendorId != null ? vendorId : "");
        bapiParams.put("IV_LIFNR_TO", vendorIdTo != null ? vendorIdTo : "");
        bapiParams.put("IV_KTOKK", vendorAccountGroup != null ? vendorAccountGroup : "");
        bapiParams.put("IV_FROM_DATE", "");
        bapiParams.put("IV_TO_DATE", "");

        request.put(BAPI_NAME, bapiParams);

        exchange.getIn().setBody(request);
        exchange.getIn().setHeader(SapBapiRoute.HEADER_BAPI_NAME, BAPI_NAME);
    }

    private void processVendorResponse(Exchange exchange) {
        JsonNode response = exchange.getIn().getBody(JsonNode.class);
        // SAP returns responses with format: rfc:BAPI_NAME.Response
        String responseKey = "rfc:" + BAPI_NAME + ".Response";
        JsonNode bapiResponse = response.path(responseKey);
        if (bapiResponse.isMissingNode()) {
            bapiResponse = response.path(BAPI_NAME);
        }

        List<Vendor> vendors = new ArrayList<>();
        List<VendorCompany> vendorCompanies = new ArrayList<>();
        List<VendorBank> vendorBanks = new ArrayList<>();

        JsonNode vendorDetails = bapiResponse.path("ET_VENDOR_DETAILS").path("item");

        if (vendorDetails.isArray()) {
            for (JsonNode item : vendorDetails) {
                Vendor vendor = mapToVendor(item);
                vendors.add(vendor);

                // Map company data (same record contains company-specific info)
                VendorCompany vc = mapToVendorCompany(item);
                if (vc.getCompanyCode() != null && !vc.getCompanyCode().isBlank()) {
                    vendorCompanies.add(vc);
                }

                // Map bank data
                VendorBank bank = mapToVendorBank(item);
                if (bank.getBankKey() != null && !bank.getBankKey().isBlank()) {
                    vendorBanks.add(bank);
                }
            }
        } else if (!vendorDetails.isMissingNode()) {
            Vendor vendor = mapToVendor(vendorDetails);
            vendors.add(vendor);
        }

        // Create result map
        Map<String, Object> result = new HashMap<>();
        result.put("vendors", vendors);
        result.put("vendorCompanies", vendorCompanies);
        result.put("vendorBanks", vendorBanks);

        exchange.getIn().setBody(result);
        exchange.getIn().setHeader("syncCount", vendors.size());

        log.info("Processed {} vendors, {} company records, {} bank records",
            vendors.size(), vendorCompanies.size(), vendorBanks.size());
    }

    private Vendor mapToVendor(JsonNode node) {
        Vendor vendor = new Vendor();
        vendor.setId(UUID.randomUUID());
        vendor.setVendorId(getText(node, "LIFNR"));
        vendor.setVendorName(getText(node, "NAME1"));
        vendor.setCountryCode(getText(node, "LAND1"));
        vendor.setCity(getText(node, "ORT01"));
        vendor.setStreet(getText(node, "STRAS"));
        vendor.setPostalCode(getText(node, "PSTLZ"));
        vendor.setRegion(getText(node, "REGIO"));
        vendor.setTelephone(getText(node, "TELF1"));
        vendor.setFax(getText(node, "TELFX"));
        vendor.setEmail(getText(node, "EMAIL"));
        vendor.setVatRegistrationNumber(getText(node, "STCEG"));
        vendor.setTaxNumber(getText(node, "TAX_NUMBER"));
        vendor.setVendorAccountGroup(getText(node, "KTOKK"));
        vendor.setIndustryCode(getText(node, "INDUSTRY"));

        // Check if blocked
        String loevm = getText(node, "LOEVM");
        vendor.setBlocked("X".equals(loevm));
        vendor.setActive(!"X".equals(loevm));

        // Extended attributes
        Map<String, Object> extended = new HashMap<>();
        addIfPresent(extended, "GSTIN", node, "GSTIN");
        addIfPresent(extended, "GST_DES", node, "GST_DES");
        addIfPresent(extended, "INSTRUCTION_KEY", node, "INSTRUCTION_KEY");
        addIfPresent(extended, "VEN_CLASS", node, "VEN_CLASS");
        addIfPresent(extended, "J_1IPANNO", node, "J_1IPANNO");
        addIfPresent(extended, "IS_SWISS", node, "IS_SWISS");
        addIfPresent(extended, "ISR_NUMBER", node, "ISR_NUMBER");
        addIfPresent(extended, "CATEGORY", node, "CATEGORY");
        vendor.setExtendedAttributes(extended);

        vendor.setCreatedBy("SAP_SYNC");
        vendor.setCreatedAt(OffsetDateTime.now());

        return vendor;
    }

    private VendorCompany mapToVendorCompany(JsonNode node) {
        VendorCompany vc = new VendorCompany();
        vc.setId(UUID.randomUUID());
        vc.setVendorId(getText(node, "LIFNR"));
        vc.setCompanyCode(getText(node, "BUKRS"));
        vc.setReconciliationAccount(getText(node, "AKONT"));
        vc.setPaymentTermsCode(getText(node, "ZTERM"));
        vc.setPaymentMethod(getText(node, "ZWELS"));
        vc.setHouseBankId(getText(node, "HBKID"));
        vc.setAlternativePayee(getText(node, "LNRZA"));

        String loevm = getText(node, "LOEVM");
        vc.setBlocked("X".equals(loevm));

        vc.setCreatedBy("SAP_SYNC");
        vc.setCreatedAt(OffsetDateTime.now());

        return vc;
    }

    private VendorBank mapToVendorBank(JsonNode node) {
        VendorBank bank = new VendorBank();
        bank.setId(UUID.randomUUID());
        bank.setVendorId(getText(node, "LIFNR"));
        bank.setBankCountry(getText(node, "BANKS"));
        bank.setBankKey(getText(node, "BANKL"));
        bank.setBankAccountNumber(getText(node, "ACC_NO"));
        bank.setIban(getText(node, "IBAN"));
        bank.setSwiftCode(getText(node, "SWIFT"));
        bank.setAccountHolderName(getText(node, "ACC_NAME"));
        bank.setBankName(getText(node, "BANK_NAME"));
        bank.setPartnerBankType(getText(node, "BVTYP"));
        bank.setBankReference(getText(node, "BKREF"));
        bank.setActive(true);

        bank.setCreatedBy("SAP_SYNC");
        bank.setCreatedAt(OffsetDateTime.now());

        return bank;
    }

    private String getText(JsonNode node, String fieldName) {
        JsonNode field = node.path(fieldName);
        if (field.isMissingNode() || field.isNull()) {
            return null;
        }
        String text = field.asText();
        return text.isBlank() ? null : text.trim();
    }

    private void addIfPresent(Map<String, Object> map, String key, JsonNode node, String fieldName) {
        String value = getText(node, fieldName);
        if (value != null) {
            map.put(key, value);
        }
    }
}
