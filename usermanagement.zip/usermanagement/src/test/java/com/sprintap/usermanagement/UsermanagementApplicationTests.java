package com.sprintap.usermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
